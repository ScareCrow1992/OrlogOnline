// for only client
import * as THREE from 'three'
import Weapon from './World/Items/Weapon.js'
import gsap from 'gsap'



function blink(material) {
    let blink_ = gsap.timeline()
    for (let i = 0; i < 3; i++) {
        blink_.to(material, { ease: "none", duration: 0.2, opacity: 1 })
        blink_.to(material, { ease: "none", duration: 0.2, opacity: 0 })
    }

    return blink_
}



function GetIncreasedMarksTransform(cnt) {
    const gap = 0.1
    let transforms = []
    const center = (cnt - 1) * gap / 2
    for (let index = 0; index < cnt; index++) {
        let dummy = new THREE.Object3D()
        let pos = -center + index * gap
        // console.log(pos)
        // dummy.position.set(pos, -pos, 0.05)
        dummy.translateX(pos)
        dummy.translateY(-pos)
        dummy.updateMatrix()
        transforms.push(dummy.matrix.clone())
        // console.log(dummy.position)
    }
    // console.log(transforms)
    return transforms
}


let godFavorsAction = {
    "Baldr": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            let helmetDicesIndex = myAvatar.GetDicesIndexsOnCondition((dice)=>{return dice.getWeapon() == "helmet"})

            // console.log(dicesIndex)

            let addedArmor = this.effectValue[level] + 1
            let helmetChangedValue = Array(helmetDicesIndex.length).fill(addedArmor)

            let promises, callbacks

            let cnt = addedArmor
            const gap = 0.1
            let transforms = []
            const center = (cnt - 1) * gap / 2
            for (let index = 0; index < cnt; index++) {
                let dummy = new THREE.Object3D()
                let pos = -center + index * gap
                // console.log(pos)
                // dummy.position.set(pos, -pos, 0.05)
                dummy.translateX(pos)
                dummy.translateY(-pos)
                dummy.updateMatrix()
                transforms.push(dummy.matrix.clone())
                // console.log(dummy.position)
            }
            // console.log(transforms)

            [promises, callbacks] = myAvatar.ConvertDiceMark("helmet", this.color, helmetDicesIndex, helmetChangedValue, transforms)

            let shieldDicesIndex = myAvatar.GetDicesIndexsOnCondition((dice)=>{return dice.getWeapon() == "shield"})

            let shieldChangedValue = Array(shieldDicesIndex.length).fill(addedArmor)

            let promises_, callbacks_

            cnt = addedArmor
            transforms = []
            const center_ = (cnt - 1) * gap / 2
            for (let index = 0; index < cnt; index++) {
                let dummy = new THREE.Object3D()
                let pos = -center_ + index * gap
                // console.log(pos)
                // dummy.position.set(pos, -pos, 0.05)
                dummy.translateX(pos)
                dummy.translateY(-pos)
                dummy.updateMatrix()
                transforms.push(dummy.matrix.clone())
                // console.log(dummy.position)
            }
            // console.log(transforms)

            [promises_, callbacks_] = myAvatar.ConvertDiceMark("shield", this.color, shieldDicesIndex, shieldChangedValue, transforms)


            await Promise.all([...promises, ...promises_])

            return [[...callbacks, ...callbacks_], []]
        }
    },
    "Bragi": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)
            
            let tokenCnt = this.effectValue[level]

            let dicesIndex = myAvatar.GetDicesIndexsOnCondition((dice)=>{return dice.getWeapon() == "steal"})

            let promises = []
            dicesIndex.forEach(index => {
                for (let i = 0; i < tokenCnt; i++){
                    let dicePosition = myAvatar.dices[index].getPosition().clone()
                    dicePosition.y += i * 0.5
                    promises.push(myAvatar.CreateNewToken(dicePosition))
                }
            })

            await Promise.all(promises)
        }
    },
    "Brunhild": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            let dicesIndex = myAvatar.GetDicesIndexsOnCondition((dice)=>{return dice.getWeapon() == "axe"})

            // console.log(dicesIndex)

            let markCnt = dicesIndex.length
            let multipliyValue = this.effectValue[level]
            let multipliedCnt = Math.ceil(markCnt * multipliyValue)
            let quotient = Math.floor(multipliedCnt / markCnt)
            let remainder = multipliedCnt % markCnt

            let changedValue = Array(markCnt).fill(quotient)
            for(let i=0; i<remainder; i++)
                changedValue[i]++
            
            
            let cnt = markCnt
            const gap = 0.1
            let transforms = []
            const center = (cnt - 1) * gap / 2
            let promises = [], callbacks = []
            for (let index = 0; index < cnt; index++) {
                let dummy

                switch(changedValue[index]){
                    case 1:
                        dummy = new THREE.Object3D()
                        transforms.push(dummy.matrix.clone())
                        break;
                    case 2:
                        dummy = new THREE.Object3D()
                        dummy.rotateZ(-0.1)
                        dummy.translateX(0.05)
                        dummy.updateMatrix()
                        transforms.push(dummy.matrix.clone())
                        
                        dummy = new THREE.Object3D()
                        dummy.rotateZ(0.1)
                        dummy.translateX(-0.05)
                        dummy.scale.set(-1,1,1)
                        dummy.updateMatrix()
                        transforms.push(dummy.matrix.clone())
                        break;

                    case 3:
                        for(let i =0 ; i < 3; i++){
                            dummy = new THREE.Object3D()
                            dummy.rotateZ( i *  2 * Math.PI / 3 + Math.PI / 6)
                            dummy.scale.set(0.85, 0.85, 0.85)
                            dummy.translateX(0.07)
                            dummy.translateY(0.07)
                            dummy.updateMatrix()
                            transforms.push(dummy.matrix.clone())
                        }
                        break;
                }

                let tmpPromises, tmpCallbacks
                [tmpPromises, tmpCallbacks] = myAvatar.ConvertDiceMark(this.weaponName, this.color, [dicesIndex[index]], [changedValue[index]], transforms)

                promises.push(...tmpPromises)
                callbacks.push(...tmpCallbacks)

            }
            await Promise.all(promises)
            return [callbacks, []]
        }
    },
    "Freyja": {
        power: async function (level, myAvatar, opponentAvatar, godFavorInfo) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            // console.log(godFavorInfo.nDiceIndexes)

            function CallLater(){
                // avatar.dices 내에 쓰레기값으로 있는 주사위들을 제거
                // console.log("garbage dice is deleted")
                myAvatar.ReduceDices(level + 1)
            }


            function CallImmediately(){
                let newDices = []
                let gap = 1.3
                let cnt = level + 1
                let anchor = -1 * (cnt - 1) * gap / 2
                let trayPosition = new THREE.Vector3(0,0, 5.5 * myAvatar.anchorSign)
                for(let i = 0; i < cnt; i++){
                    let nDice = this.CreateItem("dice", godFavorInfo.nDiceIndexes[i])
                    trayPosition.x = anchor + i * gap
                    trayPosition.y = 0.5
                    nDice.state = "waiting"
                    nDice.setPosition(trayPosition)
                    newDices.push(nDice)
                }

                myAvatar.AddDices(newDices)
                // myAvatar.AddDice(level)
            }

            return [[CallLater], [CallImmediately]]
        }
    },
    "Freyr": {
        power: async function (level, myAvatar, opponentAvatar, godFavorInfo) {
            await blink(this.effectMesh.material)

            // godFavorInfo.increasedWeapon
            // godFavorInfo.weaponIndexes
            // godFavorInfo.increasedValue

            let weapon = godFavorInfo.increasedWeapon
            let cnt = godFavorInfo.weaponIndexes.length
            // console.log(cnt)

            let promises = []
            let callbacks =[]


            for(let i=0; i<cnt; i++){
                let index = godFavorInfo.weaponIndexes[i]
                let value = godFavorInfo.increasedValue[i]

                let transforms = GetIncreasedMarksTransform(value)

                let dicesIndex = godFavorInfo.weaponIndexes[i]
                let changedValue = godFavorInfo.increasedValue[i]
                


                // console.log(dicesIndex)
                // console.log(changedValue)
                // console.log(myAvatar)

                // transforms = JSON.parse(JSON.stringify(transforms))

                let tmpPromises, tmpCallbacks
                [tmpPromises, tmpCallbacks] = myAvatar.ConvertDiceMark(weapon, this.color, [dicesIndex], [changedValue], transforms)


                promises.push(...tmpPromises)
                callbacks.push(...tmpCallbacks)
            }

            await Promise.all(promises)
            return [callbacks, []]

        }
    },
    "Frigg": {
        power: async function (level, myAvatar, opponentAvatar, godFavorInfo) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            // console.log(godFavorInfo.nDiceIndexes)
            let rerollDiceCnt = this.effectValue[level]

            function CallImmediately(){
                // console.log(avatarsIndex)
                // console.log("Loki power")
                this.extraPickedDiceCnt = rerollDiceCnt
                let avatarsIndex = this.GetAvatarsIndex()

                this.EnableExtraInputDice({
                    trigger : "Resolution",
                    user : avatarsIndex[godFavorInfo.user],
                    godfavor : "Frigg"
                })
                // myAvatar.AddDice(level)
            }

            return [null, [CallImmediately]]
        }
    },
    "Heimdall": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)
            
            let healValue = this.effectValue[level]

            myAvatar.eventEmitter.on(`${myAvatar.index}-block-axe`, () => {
                for (let i = 0; i < healValue; i++)
                    myAvatar.Heal()
            })

            myAvatar.eventEmitter.on(`${myAvatar.index}-block-arrow`, () => {
                for (let i = 0; i < healValue; i++)
                    myAvatar.Heal()
            })
        }
    },
    "Hel": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            // 트리거 등록
            let healValue = this.effectValue[level]

            for (let i = 0; i < healValue; i++){

            }

            myAvatar.eventEmitter.on(`${opponentAvatar.index}-damage-axe`, () => {
                for (let i = 0; i < healValue; i++)
                    myAvatar.Heal()
            })

            myAvatar.eventEmitter.on(`${opponentAvatar.index}-damage-axe-anim`, () => {
                for (let i = 0; i < healValue; i++)
                    myAvatar.HealAnimation()
            })




            // 마크 변경
            let dicesIndex = myAvatar.GetDicesIndexsOnCondition((dice)=>{return dice.getWeapon() == "axe"})


            let changedValue = Array(dicesIndex.length).fill(1)

            let promises, callbacks

            let cnt = 1
            const gap = 0.1
            let transforms = []
            const center = (cnt - 1) * gap / 2
            for (let index = 0; index < cnt; index++) {
                let dummy = new THREE.Object3D()
                let pos = -center + index * gap
                // console.log(pos)
                // dummy.position.set(pos, -pos, 0.05)
                dummy.translateX(pos)
                dummy.translateY(-pos)
                dummy.updateMatrix()
                transforms.push(dummy.matrix.clone())
                // console.log(dummy.position)
            }
            // console.log(transforms)

            [promises, callbacks] = myAvatar.ConvertDiceMark(this.weaponName, this.color, dicesIndex, changedValue, transforms)

            await Promise.all(promises)

            return [callbacks, []]
        }
    },
    "Idun": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)


            let healValue = this.effectValue[level]
            let promises = []
            for (let i = 0; i < healValue; i++)
                promises.push(myAvatar.Heal())

            // return Promise.all(promise)
            await Promise.all(promises)

            promises.length = 0
            for (let i = 0; i < healValue; i++)
                promises.push(myAvatar.HealAnimation())

            await Promise.all(promises)
        }
    },
    "Loki": {
        power: async function (level, myAvatar, opponentAvatar, godFavorInfo) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            // console.log(godFavorInfo.nDiceIndexes)
            let banDiceCnt = this.effectValue[level]

            function CallImmediately(){
                // console.log(avatarsIndex)
                // console.log("Loki power")
                this.extraPickedDiceCnt = banDiceCnt
                let avatarsIndex = this.GetAvatarsIndex()

                this.EnableExtraInputDice({
                    trigger : "Resolution",
                    user : avatarsIndex[godFavorInfo.user],
                    godfavor : "Loki"
                })
                // myAvatar.AddDice(level)
            }

            return [null, [CallImmediately]]
        }
    },
    "Mimir": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            
            let tokenCnt = this.effectValue[level] 
            myAvatar.eventEmitter.on(`${myAvatar.index}-damage-axe`, (position)=>{
                for(let i = 0; i< tokenCnt; i++){
                    let newPosition = position.clone()
                    newPosition.y += i * 0.3
                    myAvatar.CreateNewToken(newPosition)
                }
            })

            myAvatar.eventEmitter.on(`${myAvatar.index}-damage-arrow`, (position)=>{
                for(let i = 0; i< tokenCnt; i++){
                    let newPosition = position.clone()
                    newPosition.y += i * 0.3
                    myAvatar.CreateNewToken(newPosition)
                }
            })

            myAvatar.eventEmitter.on(`${myAvatar.index}-damage-godfavor`, (position)=>{
                for(let i = 0; i< tokenCnt; i++){
                    let newPosition = position.clone()
                    newPosition.y += i * 0.3
                    myAvatar.CreateNewToken(newPosition)
                }
            })
        }
    },
    "Odin": {
        power: async function (level, myAvatar, opponentAvatar, godFavorInfo) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            // let consumedHealth = 4
            // let newTokenCnt = this.effectValue[level]

            // let promises = []
            // for (let healthCnt = 0; healthCnt < consumedHealth; healthCnt++) {
            //     let healthStonePosition = myAvatar.GetTargetHealthStone(null)
            //     for (let tokenCnt = 0; tokenCnt < newTokenCnt; tokenCnt++) {
            //         let healthStonePosition_ = healthStonePosition.clone()
            //         healthStonePosition_.y += 0.25 * tokenCnt
            //         promises.push(myAvatar.CreateNewToken(healthStonePosition_))
            //     }
            // }
            // await Promise.all(promises)

            function CallImmediately(){
                // console.log(avatarsIndex)
                // console.log("Loki power")
                let avatarsIndex = this.GetAvatarsIndex()

                this.EnableExtraInputDice({
                    trigger : "Resolution",
                    user : avatarsIndex[godFavorInfo.user],
                    godfavor : "Odin"
                })
                // myAvatar.AddDice(level)
            }


            return [null, [CallImmediately]]
        },
        extraPower: async function (level, myAvatar, opponentAvatar, godFavorInfo, param) {
            let damage = param.damage
            let coefficient = param.coefficient

            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            let prom = [];
            for (let index = 0; index < damage; index++) {
                let pos = myAvatar.GetTargetHealthStone()

                for (let j = 0; j < coefficient; j++) {
                    let pos_ = pos.clone()
                    pos_.y = 0.2 * (j + 1)
                    prom.push(myAvatar.CreateNewToken(pos_))
                }
            }
            myAvatar.HealthStonesInteractOff()

            return Promise.all(prom)
        }
    },
    "Skadi": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            let dicesIndex = myAvatar.GetDicesIndexsOnCondition((dice)=>{return dice.getWeapon() == "arrow"})

            // console.log(dicesIndex)

            let addedArrow = this.effectValue[level] + 1
            let changedValue = Array(dicesIndex.length).fill(addedArrow)


            let promises, callbacks

            let cnt = addedArrow
            const gap = 0.1
            let transforms = []
            const center = (cnt - 1) * gap / 2
            for (let index = 0; index < cnt; index++) {
                let dummy = new THREE.Object3D()
                let pos = -center + index * gap
                // console.log(pos)
                // dummy.position.set(pos, -pos, 0.05)
                dummy.translateX(pos)
                dummy.translateY(-pos)
                dummy.updateMatrix()
                transforms.push(dummy.matrix.clone())
                // console.log(dummy.position)
            }
            // console.log(transforms)

            [promises, callbacks] = myAvatar.ConvertDiceMark(this.weaponName, this.color, dicesIndex, changedValue, transforms)

            await Promise.all(promises)

            return [callbacks, []]
        }
    },
    "Skuld": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)
            
            let tokenBrokenCoefficient = this.effectValue[level]
            let arrowDicesIndex = myAvatar.GetDicesIndexsOnCondition((dice)=>{return dice.getWeapon() == "arrow"})
            let arrowCnt = arrowDicesIndex.length

            await opponentAvatar.SpendToken(tokenBrokenCoefficient * arrowCnt)
        }
    },
    "Thor": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)


            let anim = gsap.timeline()

            // if(!this.CheckCanUse(args.level))
            //     return null
            let promises = []
            // console.log("hammer time")
            for (let index = 0; index < this.effectValue[level]; index++) {
                let muzzle = this.getPosition()
                let weapon = new Weapon("mjolnir")
                weapon.SetPosition(muzzle)

                let target = weapon.GetTarget(opponentAvatar)
                if (target != null) {
                    promises.push(weapon.Action(target, opponentAvatar))
                }

            }

            await Promise.all(promises).then((resolves) => { resolves.forEach(callback => { callback() }) })

            // return anim
        }
    },
    "Thrymr": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

        }
    },
    "Tyr": {
        power: async function (level, myAvatar, opponentAvatar, godFavorInfo) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)
            function CallImmediately(){
                let avatarsIndex = this.GetAvatarsIndex()

                this.EnableExtraInputDice({
                    trigger : "Resolution",
                    user : avatarsIndex[godFavorInfo.user],
                    godfavor : "Tyr"
                })
                // myAvatar.AddDice(level)
            }


            return [null, [CallImmediately]]
        },
        extraPower: async function (level, myAvatar, opponentAvatar, godFavorInfo, param) {
            let damage = param.damage
            let coefficient = param.coefficient

            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            let prom = [];
            for (let index = 0; index < damage; index++) {
                myAvatar.GetTargetHealthStone()

                prom.push(opponentAvatar.SpendToken(coefficient))
            }
            myAvatar.HealthStonesInteractOff()

            return Promise.all(prom)
        }
    },
    "Ullr": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)
        }

    },
    "Var": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)

            let healCoefficient = this.effectValue[level] 
            myAvatar.eventEmitter.on(`${opponentAvatar.index}-use-token`, (tokenCnt)=>{
                let healValue = healCoefficient * tokenCnt
                for (let i = 0; i < healValue; i++) {
                    myAvatar.Heal()
                }
            })

        }
    },
    "Vidar": {
        power: async function (level, myAvatar, opponentAvatar) {
            // myAvatar.SpendToken(this.cost[level])
            await blink(this.effectMesh.material)
        }
    }


}


// let godFavorsExtraAction = {
//     "Odin" : {
//         async function (level, myAvatar, opponentAvatar, godFavorInfo) {
//             // myAvatar.SpendToken(this.cost[level])
//             await blink(this.effectMesh.material)
            

//         }
//     }
// }



export {godFavorsAction}