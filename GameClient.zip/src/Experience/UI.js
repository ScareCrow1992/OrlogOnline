import * as THREE from 'three'
import Experience from './Experience.js'
import Dice from './World/Items/Dice.js'
import GodFavor from './World/GodFavor.js'
import EventEmitter from './Utils/EventEmitter.js'

// import { nodeFrame } from 'three/examples/jsm/renderers/webgl/nodes/WebGLNodes.js';

export default class UI extends EventEmitter {
    constructor() {
        super()
        this.experience = new Experience()
        this.camera = this.experience.camera
        this.sizes = this.experience.sizes;
        this.phase = "Roll"
        this.godFavorActivation = null
        this.godFavorActivation_level = null

        this.notice_opacity = 1
        this.alert_opacity = 0
        this.description_opacity = 0

        // this.setInstance()
        this.infoUIdom = document.getElementsByClassName("info-ui")[0];
        this.infoUItextdom = document.getElementsByClassName("info-ui-txt")[0];
        
        this.topGodFavorUIDom = document.getElementById("top-player");
        this.topGodFavorUItextDom = document.getElementById("top-player").children[0];

        this.bottomGodFavorUIDom = document.getElementById("bottom-player");
        this.bottomGodFavorUItextDom = document.getElementById("bottom-player").children[0];

        this.topGodFavorUIButton = []
        this.bottomGodFavorUIButton = []

        for(let i=0; i<3; i++){
            let dom_bottom = this.bottomGodFavorUItextDom.children[3].children[i]
            this.bottomGodFavorUIButton.push(dom_bottom)

            
            let dom_top = this.topGodFavorUItextDom.children[3].children[i]
            this.topGodFavorUIButton.push(dom_top)
        }

        this.r2_url = "https://orlog-online.com"

        var dice_blue_print_cells = this.infoUIdom.children[0].children[2]
        var dice_tokenmark_dom = document.createElement('img')
        dice_tokenmark_dom.classList.add("img-token")
        dice_tokenmark_dom.src = `${this.r2_url}/textures/dice/Token.png`

        dice_blue_print_cells.children[1].appendChild(dice_tokenmark_dom.cloneNode())
        dice_blue_print_cells.children[3].appendChild(dice_tokenmark_dom.cloneNode())
        dice_blue_print_cells.children[4].appendChild(dice_tokenmark_dom.cloneNode())
        dice_blue_print_cells.children[5].appendChild(dice_tokenmark_dom.cloneNode())
        dice_blue_print_cells.children[7].appendChild(dice_tokenmark_dom.cloneNode())
        dice_blue_print_cells.children[10].appendChild(dice_tokenmark_dom.cloneNode())

        // console.log(dice_blue_print_cells)
        // 1,3,4,5,7,10,




        // console.log(this.bottomGodFavorUItextDom)

        this.noticeUIDom = document.getElementById("notice-ui-txt")
        this.noticeUIShowKeyframe = [
            {opacity : 0},
            {opacity : 1, offset : 0.15},
            {opacity : 1, offset : 0.85},
            {opacity : 0}]

        this.descriptionUIDom = document.getElementById("description-ui-txt")
        this.descriptionText = {
            "godfavor" : "Select a God Favor, or Skip"
        }
        
        this.alertUIDom = document.getElementById("alert-ui-txt")

        this.selectedGodFavor = null;
        this.godFavorInfo = null

        // this.infoGodFavorUITextdom = document.getElementById


        this.infoUIanchor = new THREE.Vector3(5, 0, 0);


        this.experience.resources.on('ready', () => {
            // console.log(this.infoUIdom)
            // console.log(this.infoUItextdom)
            // console.log(this.infoUItextdom.children[2].children);

            // console.log(this.infoUItextdom.children)
            this.diceDescriptionCellDom = this.infoUItextdom.children[0].children[0]
            this.diceTokenDescriptioncellDom = this.infoUItextdom.children[0].children[1]
            

            // console.log(diceDescriptionCell)
            let diceBluePrintCells = this.infoUItextdom.children[2].children
            let indexes = [1,3,4,5,7,10];
            let faces = ["top", "left", "front", "right", "bottom", "back"]
            this.diceBlueprintCellDoms = {};

            for (let i = 0; i < 6; i++) {
                let index = indexes[i]
                let face = faces[i]
                this.diceBlueprintCellDoms[`${face}`] = {}
                let cellDom = this.diceBlueprintCellDoms[`${face}`]

                cellDom.weapon = diceBluePrintCells[index]
                cellDom.token = diceBluePrintCells[index].children[0]
            }


            for(let level=0; level<3; level++){
                let godFavorButton = this.bottomGodFavorUItextDom.children[3].children[level]

                godFavorButton.addEventListener("click", ()=>{
                    // console.log(this.selectedGodFavor)
                    // console.log(this.godFavorInfo)
                    // console.log(level)

                    let godFavorIndex = this.godFavorInfo.index
                    let avatarIndex = this.godFavorInfo.avatar

                    // if (avatarIndex == 1)
                    this.trigger("god_favor_action", [godFavorIndex, level, avatarIndex])
                })
            }
        })
    }


    update(){

        // ui가 object3d를 따라가게 만들기

        // var screenPosition = this.infoUIanchor.clone();
        // screenPosition.project(this.camera.instance);
        // // // console.log(screenPosition);
        
        // const translateX = screenPosition.x * this.sizes.width * 0.5
        // const translateY = - screenPosition.y * this.sizes.height * 0.5
        // this.infoUIdom.style.transform = `translateX(${translateX}px) translateY(${translateY}px)`


    }


    GodFavorPowerUI_Deactivate() {
        if (this.godFavorActivation != null) {
            this.topGodFavorUItextDom.classList.remove("visible")
            if (this.godFavorActivation_level >= 0)
                this.topGodFavorUIButton[this.godFavorActivation_level].classList.remove("highlight")
        }

        this.godFavorActivation = null
        this.godFavorActivation_level = null
    }

    GodFavorPowerUI_Activate(godFavor, level) {
        if (this.godFavorActivation != null) {
            // 기존에 활성화된 ui 정보 삭제
            this.GodFavorPowerUI_Deactivate()
        }

        this.godFavorActivation = godFavor
        this.godFavorActivation_level = level

        this.godFavorHovered(godFavor, this.topGodFavorUItextDom)
        this.topGodFavorUItextDom.classList.add("visible")
        if (this.godFavorActivation_level >= 0)
            this.topGodFavorUIButton[this.godFavorActivation_level].classList.add("highlight")
    }


    click(obj, objInfo){
        // let obj = this.experience.world.gameObjects[`${objID}`]
            
        
        if(obj instanceof Dice){
            this.hover_off()
        }
        
        if(obj instanceof GodFavor && this.phase == "godfavor"){
            // console.log(obj)

            this.selectedGodFavor = obj;
            this.godFavorInfo = objInfo
            // console.log(objInfo)
    
            // if(obj.avatar == 0)
            //     this.topGodFavorUItextDom.classList.add("unfold")
            // if(objInfo.isBottom)
            this.bottomGodFavorUItextDom.classList.add("unfold")

        }
    }

    emptyclick(){
        this.bottomGodFavorUItextDom.classList.remove("unfold")
        // this.topGodFavorUItextDom.classList.remove("unfold")
        this.selectedGodFavor = null;

    }


    GameOver(txt){
        this.noticeUIDom.innerHTML = txt
        this.noticeUIDom.animate(this.noticeUIShowKeyframe, {delay : 200, duration : 2200})

    }


    viewDescriptionDuration(text, duration){
        this.showDescription(text)
        setTimeout(()=>{this.hideDescription()}, duration * 1000 + 500)
    }


    phaseEnd(phase){
        switch(phase){
        case "godfavor":
            this.hideDescription()
            break;

        }
    }


    phaseStart(phase){                
        this.showNotice(phase)
        this.phase = phase
        // console.log(phase)
        switch(phase){
            case "godfavor":
                this.showPhaseChangeDescription(phase)

            break;
        }

    }


    WriteOnNotice(text){
        this.noticeUIDom.innerHTML = text
        this.noticeUIDom.animate(this.noticeUIShowKeyframe, {delay : 200, duration : 2200})

        return setTimeout(()=>{}, 2200)
    }

    showNotice(phase){
        let firstChar = phase.charAt(0);
        let others = phase.slice(1);

        let description = firstChar.toUpperCase() + others + " phase";

        this.noticeUIDom.innerHTML = description
        this.noticeUIDom.animate(this.noticeUIShowKeyframe, {delay : 200, duration : 2200})
    }

    showDescription(text){
        this.descriptionUIDom.innerText = text
        this.descriptionUIDom.animate([{opacity : this.description_opacity},{opacity : 1}], {fill: "forwards", duration : 500})
        this.description_opacity = 1
    }

    showPhaseChangeDescription(phase){
        this.descriptionUIDom.innerText = this.descriptionText[`${phase}`]
        this.descriptionUIDom.animate([{opacity : 0},{opacity : 1}], {fill: "forwards", delay : 2200, duration : 500})
        this.description_opacity = 1
    }

    showAlert(text){
        this.alertUIDom.innerText = text
        this.alertUIDom.animate([{opacity : this.alert_opacity},{opacity : 1}], {fill: "forwards", duration : 500})
        this.alert_opacity = 1
    }

    hideAlert(){
        this.alertUIDom.animate([{opacity : this.alert_opacity},{opacity : 0}], {fill: "forwards", duration : 500})
        this.alert_opacity = 0
    }

    showAlertDuration(text, duration){
        this.showAlert(text)
        setTimeout(()=>{this.hideAlert()}, duration * 1000 + 500)

    }

    hideDescription(){

        this.descriptionUIDom.animate([{opacity : this.description_opacity},{opacity : 0}], {fill: "forwards", duration : 500})    
        this.description_opacity = 0
    }

    hover_on(objID){
        // console.log(this.infoUItextdom);
        // this.infoUItextdom.innerHTML = `hovered intem : ID (${objID})`;
        // ${this.experience.world.gameObjects[`${objID}`]}
    
        let obj = this.experience.world.gameObjects[`${objID}`]
        if(obj == null || obj == undefined)
            return;

        if(obj instanceof Dice){
            this.diceHovered(obj)
            this.infoUItextdom.classList.add("visible");
        }
        else if (obj instanceof GodFavor) {
            if (this.godFavorActivation_level != null && this.godFavorActivation_level >= 0)
                this.bottomGodFavorUIButton[this.godFavorActivation_level].classList.remove("highlight")

            this.godFavorHovered(obj, this.bottomGodFavorUItextDom)
            this.bottomGodFavorUItextDom.classList.add("visible")
        }
    }

    hover_off(){
        this.infoUItextdom.classList.remove("visible");
        this.bottomGodFavorUItextDom.classList.remove("visible")

    }


    godFavorPhaseOn(){
        // console.log("God Favor Phase is Start")
        this.phase = "GodFavor"
    }


    godFavorPhaseOff(){
        // bottom 플레이어가 스킬을 안쓰는 경우
        // this.bottomGodFavorUItextDom.classList.remove("unfold")
     
    
        this.hover_off()
    }


    diceHovered(dice){
        // console.log(dice)
        
        // let weapons = ["Axe", "Shield", "Arrow", "Axe", "Helmet", "StealFavor"]
        // let token = [false, false, true, false, false, true]
        

        // this.diceDescriptionCellDom.innerHTML = `Block 1<img class="img-inside-text" src="/textures/dice/Axe.png">damage`

        // console.log(this.diceDescriptionCellDom)
        // console.log(upFace)


        // description
        // this.diceDescriptionCellDom


        switch(dice.getWeapon()){
            case "arrow" :
                this.diceDescriptionCellDom.innerHTML = `Deal 1
                <span class = "img-inside-text-wrapper">
                    <img class="img-inside-text" src="${this.r2_url}/textures/dice/Arrow.png">
                </span>
                damage`
            break;

            case "axe" :
                this.diceDescriptionCellDom.innerHTML = `Deal 1
                <span class = "img-inside-text-wrapper">
                    <img class="img-inside-text" src="${this.r2_url}/textures/dice/Axe.png">
                </span>
                damage`
                break;
                
            case "shield" :
                this.diceDescriptionCellDom.innerHTML = `Block 1
                <span class = "img-inside-text-wrapper">
                    <img class="img-inside-text" src="${this.r2_url}/textures/dice/Shield.png">
                </span>
                damage`
                break;
                
            case "helmet" :
                this.diceDescriptionCellDom.innerHTML = `Block 1
                <span class = "img-inside-text-wrapper">
                    <img class="img-inside-text" src="${this.r2_url}/textures/dice/Helmet.png">
                </span>
                damage`
                break;
                
            case "steal" :
                this.diceDescriptionCellDom.innerHTML = `Steal 1
                <span class="token-text">⌘</span>
                from the opponent.`
                break;       
        }

        if(dice.isToken())
            this.diceTokenDescriptioncellDom.style.display = "block"
        else
            this.diceTokenDescriptioncellDom.style.display = "none"



        // console.log(this.diceDescriptionCellDom)




        // blueprint

        let weaponFiles = { axe : "Axe", shield : "Shield", arrow: "Arrow", helmet : "Helmet", steal : "StealFavor"}

        // console.log(this.diceBlueprintCellDoms)

        let faces = dice.getFaces()

        Object.keys(faces).forEach(dir =>{
            let face = faces[`${dir}`]
            
            let weaponFile = face.weaponType
            // console.log(weaponFile)
            let weaponFilesName = weaponFiles[`${weaponFile}`]


            let cellDom = this.diceBlueprintCellDoms[`${dir}`]
            // console.log(`url("/textures/dice/ACV-"${weaponFilesName}"Orlog.webp")`)
            cellDom.weapon.style.backgroundImage = `url("${this.r2_url}/textures/dice/ACV-${weaponFilesName}Orlog.webp")`
            // "url(\"/textures/dice/ACV-" + `${weaponFilesName}` + "Orlog.webp\")"

            cellDom.weapon.style.overflow = "hidden"

            // 상단면만 밝은색으로
            
            if(dice.getUpDir() == dir)
                cellDom.weapon.style.filter = "brightness(100%)"
            else
                cellDom.weapon.style.filter = "brightness(30%)"
            



            if(face.isToken)
                cellDom.token.style.visibility = "visible"
            else
                cellDom.token.style.visibility = "hidden"
        })


        // for(let i=0; i<6; i++){
        //     let weapon = dice.diceFaces[i]
        //     let face = faces[i];

        //     let index = indexes[i]
        //     // let face = faces[i]
            
        //     let cellDom = this.diceBlueprintCellDoms[`${face}`]
        //     cellDom.weapon.style.backgroundImage = `url("/textures/dice/ACV-${weapons[i]}Orlog.webp")`

        //     cellDom.weapon.style.overflow = "hidden"
        //     cellDom.weapon.style.filter = "brightness(100%)"

        //     if(token[i])
        //         cellDom.token.style.visibility = "visible"
        //     else
        //         cellDom.token.style.visibility = "hidden"

        // }


    }


    godFavorHovered(godFavor, dom){
        // console.log(godFavor)
        // console.log(this.bottomGodFavorUItextDom)

        // console.log(godFavor.info.spec(1));

        let title = dom.children[0]
        
        let description = dom.children[1].children[0]
        let invoke = dom.children[1].children[1].children[0]
        let priority = dom.children[1].children[1].children[1]

        //let cost = dom.children[3][0~2][0]
        //let effect = dom.children[3][0~2][1]

        let power = []

        for(let index=0; index<3; index++){
            var obj = {};
            obj.cost = dom.children[3].children[index].children[0].children[0]
            obj.effect = dom.children[3].children[index].children[0].children[1]
            power.push(obj)
        }

        title.innerText = godFavor.info.title;
        description.innerHTML = godFavor.info.description;
        let str = godFavor.info.description
        // str = str.replace("{ARROW}", `<span class = "img-inside-text-wrapper"><img class="img-inside-text" src="/textures/dice/Arrow.png"></span>`)
        str = this.TextConvertToIcon(str, false)
        description.innerHTML = str

        invoke.innerText = "Invoke : " + `${godFavor.info.afterDecision ? "After ⚠️" : "Before"}`
        priority.innerText = "Priority : " + godFavor.info.priority

        
        for (let index = 0; index < 3; index++) {
            power[index].cost.innerHTML = godFavor.info.cost[index] + ` <span class="token-text-small">⌘</span>`
            let str = godFavor.info.spec(index)
            str = this.TextConvertToIcon(str, true)
            power[index].effect.innerHTML = str
        }

    }



    TextConvertToIcon(txt, small = true){
        let formats = ["ARROW", "AXE", "HELMET", "SHIELD", "STEAL"]
        let links = ["Arrow", "Axe", "Helmet", "Shield", "Steal"]
        let size = ""
        if(small)
            size = "-small"
        for(let index= 0; index < 5; index++){
            txt = txt.replaceAll(`{${formats[index]}}`, `<span class = "img-inside-text-wrapper${size}"><img class="img-inside-text${size}" src="${this.r2_url}/textures/dice/${links[index]}.png"></span>`)
        }


        txt = txt.replaceAll("⌘", `<span class="token-text${size}">⌘</span>`)

        return txt
    }


}


// <span class="token-text">⌘</span>