
export default [
    {
        name: 'environmentMapTexture',
        type: 'cubeTexture',
        path:
        [
            '/textures/environmentMap/px.jpg',
            '/textures/environmentMap/nx.jpg',
            '/textures/environmentMap/py.jpg',
            '/textures/environmentMap/ny.jpg',
            '/textures/environmentMap/pz.jpg',
            '/textures/environmentMap/nz.jpg'
        ]
    },
    {
        name: 'grassColorTexture',
        type: 'texture',
        path: '/textures/dirt/color.jpg'
    },
    {
        name: 'grassNormalTexture',
        type: 'texture',
        path: '/textures/dirt/normal.jpg'
    },
    {
        name: 'axeModel',
        type: 'gltfModel',
        path: '/models/Weapon/axe.glb'
    },
    {
        name: 'arrowModel',
        type: 'gltfModel',
        path: '/models/Weapon/arrow.glb'
    },
    {
        name: 'bowModel',
        type: 'gltfModel',
        path: '/models/Weapon/bow.glb'
    },
    {
        name: 'helmetModel',
        type: 'gltfModel',
        path: '/models/Weapon/helmet.glb'
    },
    {
        name: 'shieldModel',
        type: 'gltfModel',
        path: '/models/Weapon/shield.glb'
    },
    {
        name: 'mjolnirModel',
        type: 'gltfModel',
        path: '/models/Weapon/mjolnir.glb'
    },
    {
        name: 'mjolnir2Model',
        type: 'gltfModel',
        path: '/models/Weapon/mjolnir2.glb'
    },
    {
        name: 'tableModel',
        type: 'gltfModel',
        path: '/models/Weapon/table.glb'
    },


    {
        name: 'stampModel',
        type: 'gltfModel',
        path: '/models/Collections/stamp.glb'
    },

    {
        name: 'stamp_ao',
        type: 'texture',
        path: '/textures/stamp/ao.jpg'
    },
    {
        name: 'stamp_map',
        type: 'texture',
        path: '/textures/stamp/map.jpg'
    },
    {
        name: 'stamp_normal',
        type: 'texture',
        path: '/textures/stamp/normal.jpg'
    },
    {
        name: 'stamp_roughness',
        type: 'texture',
        path: '/textures/stamp/roughness.jpg'
    },


    {
        name: 'foxModel',
        type: 'gltfModel',
        path: '/models/Fox/glTF/Fox.gltf'
    },
    {
        name: 'diceArrowTexture',
        type: 'texture',
        path: '/textures/dice/ACV-ArrowOrlog.webp'
    },
    {
        name: 'diceAxeTexture',
        type: 'texture',
        path: '/textures/dice/ACV-AxeOrlog.webp'
    },
    {
        name: 'diceGodFavorTexture',
        type: 'texture',
        path: '/textures/dice/ACV-GodFavorOrlog.webp'
    },
    {
        name: 'diceHelmetTexture',
        type: 'texture',
        path: '/textures/dice/ACV-HelmetOrlog.webp'
    },
    {
        name: 'diceShieldTexture',
        type: 'texture',
        path: '/textures/dice/ACV-ShieldOrlog.webp'
    },
    {
        name: 'diceStealTexture',
        type: 'texture',
        path: '/textures/dice/ACV-StealFavorOrlog.webp'
    },
    {
        name: 'ArrowMark',
        type: 'texture',
        path: '/textures/dice/Arrow.png'
    },
    {
        name: 'AxeMark',
        type: 'texture',
        path: '/textures/dice/Axe.png'
    },
    {
        name: 'HelmetMark',
        type: 'texture',
        path: '/textures/dice/Helmet.png'
    },
    {
        name: 'ShieldMark',
        type: 'texture',
        path: '/textures/dice/Shield.png'
    },
    {
        name: 'StealMark',
        type: 'texture',
        path: '/textures/dice/Steal.png'
    },
    {
        name: 'TokenMark',
        type: 'texture',
        path: '/textures/dice/Token.png'
    }

    ,
    {
        name: 'godBaldrTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Baldr.webp'
    },
    {
        name: 'godBragiTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Bragi.webp'
    },
    {
        name: 'godBrunhildTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Brunhild.webp'
    },
    {
        name: 'godFreyjaTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Freyja.webp'
    },
    {
        name: 'godFreyrTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Freyr.webp'
    },
    {
        name: 'godFriggTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Frigg.webp'
    },
    {
        name: 'godHeimdallTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Heimdall.webp'
    },
    {
        name: 'godHelTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Hel.webp'
    },
    {
        name: 'godIdunTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Idun.webp'
    },
    {
        name: 'godLokiTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Loki.webp'
    },
    {
        name: 'godMimirTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Mimir.webp'
    },
    {
        name: 'godOdinTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Odin.webp'
    },
    {
        name: 'godSkadiTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Skadi.webp'
    },
    {
        name: 'godSkuldTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Skuld.webp'
    },
    {
        name: 'godThorTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Thor.webp'
    },
    {
        name: 'godThrymrTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Thrymr.webp'
    },
    {
        name: 'godTyrTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Tyr.webp'
    },
    {
        name: 'godUllrTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Ullr.webp'
    },
    {
        name: 'godVarTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Var.webp'
    },
    {
        name: 'godVidarTexture',
        type: 'texture',
        path: '/textures/godfavor/ACV_Orlog_Vidar.webp'
    },


    {
        name: 'godBaldrNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Baldr.png'
    },
    {
        name: 'godBragiNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Bragi.png'
    },
    {
        name: 'godBrunhildNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Brunhild.png'
    },
    {
        name: 'godFreyjaNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Freyja.png'
    },
    {
        name: 'godFreyrNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Freyr.png'
    },
    {
        name: 'godFriggNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Frigg.png'
    },
    {
        name: 'godHeimdallNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Heimdall.png'
    },
    {
        name: 'godHelNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Hel.png'
    },
    {
        name: 'godIdunNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Idun.png'
    },
    {
        name: 'godLokiNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Loki.png'
    },
    {
        name: 'godMimirNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Mimir.png'
    },
    {
        name: 'godOdinNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Odin.png'
    },
    {
        name: 'godSkadiNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Skadi.png'
    },
    {
        name: 'godSkuldNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Skuld.png'
    },
    {
        name: 'godThorNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Thor.png'
    },
    {
        name: 'godThrymrNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Thrymr.png'
    },
    {
        name: 'godTyrNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Tyr.png'
    },
    {
        name: 'godUllrNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Ullr.png'
    },
    {
        name: 'godVarNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Var.png'
    },
    {
        name: 'godVidarNormalmapTexture',
        type: 'texture',
        path: '/textures/godfavor/normalMap/Vidar.png'
    },
    // {
    //     name: 'trayWoodTexture',
    //     type: 'texture',
    //     path: '/textures/wood/wood_color.jpg'
    // },
    // {
    //     name: 'trayWoodNormalmapTexture',
    //     type: 'texture',
    //     path: '/textures/wood/wood_roughness.jpg'
    // },
    // {
    //     name: 'towelTexture',
    //     type: 'texture',
    //     path: '/textures/towel/blue_towel_texture.jpg'
    // },
    // {
    //     name: 'godThorSVG',
    //     type: 'svg',
    //     path: '/textures/godfavor/svg/Thor.svg'
    // },
    {
        name: 'godsymbolDisp',
        type: 'texture',
        path: '/textures/godsymbol/displacement.png'
    },
    {
        name: 'godsymbolDisp2',
        type: 'texture',
        path: '/textures/godsymbol/displacement_.png'
    },
    {
        name: 'godsymbolNormal',
        type: 'texture',
        path: '/textures/godsymbol/normalmap.png'
    },
    {
        name: 'godsymbolNormal2',
        type: 'texture',
        path: '/textures/godsymbol/normalmap2.png'
    },
    {
        name: 'godsymbolNoise',
        type: 'texture',
        path: '/textures/godsymbol/Perlin_noise_example.png'
    },
    {
        name: 'godsymbolAO',
        type: 'texture',
        path: '/textures/godsymbol/AOmap.png'
    },
    {
        name: 'godsymbolAO2',
        type: 'texture',
        path: '/textures/godsymbol/AOmap2.png'
    },
    {
        name: 'godsymbolDiffuse',
        type: 'texture',
        path: '/textures/godsymbol/diffuseMap.jpg'
    },
    // {
    //     name: 'denmin_fabric_02_ao',
    //     type: 'texture',
    //     path: '/textures/denmin_fabric_02_4k/textures/denmin_fabric_02_ao_4k.png'
    // },
    // {
    //     name: 'denmin_fabric_02_arm',
    //     type: 'texture',
    //     path: '/textures/denmin_fabric_02_4k/textures/denmin_fabric_02_arm_4k.png'
    // },
    // {
    //     name: 'denmin_fabric_02_diff',
    //     type: 'texture',
    //     path: '/textures/denmin_fabric_02_4k/textures/denmin_fabric_02_diff_4k.png'
    // },
    // {
    //     name: 'denmin_fabric_02_nor',
    //     type: 'texture',
    //     path: '/textures/denmin_fabric_02_4k/textures/denmin_fabric_02_nor_gl_4k.png'
    // },
    // {
    //     name: 'denmin_fabric_02_rough',
    //     type: 'texture',
    //     path: '/textures/denmin_fabric_02_4k/textures/denmin_fabric_02_rough_4k.png'
    // }

    // ,
    // {
    //     name: 'wood_table_001_ao',
    //     type: 'texture',
    //     path: '/textures/wood_table_001_4k/textures/wood_table_001_ao_4k.png'
    // },
    // {
    //     name: 'wood_table_001_arm',
    //     type: 'texture',
    //     path: '/textures/wood_table_001_4k/textures/wood_table_001_arm_4k.png'
    // },
    // {
    //     name: 'wood_table_001_diff',
    //     type: 'texture',
    //     path: '/textures/wood_table_001_4k/textures/wood_table_001_diff_4k.png'
    // },
    // {
    //     name: 'wood_table_001_disp',
    //     type: 'texture',
    //     path: '/textures/wood_table_001_4k/textures/wood_table_001_disp_4k.png'
    // },
    // {
    //     name: 'wood_table_001_nor',
    //     type: 'texture',
    //     path: '/textures/wood_table_001_4k/textures/wood_table_001_nor_gl_4k.png'
    // },
    // {
    //     name: 'wood_table_001_rough',
    //     type: 'texture',
    //     path: '/textures/wood_table_001_4k/textures/wood_table_001_rough_4k.png'
    // },



    {
        name: 'wood_table_worn_diff',
        type: 'texture',
        path: '/textures/wood_table_worn_4k/textures/wood_table_worn_diff_4k.jpg'
    },
    {
        name: 'wood_table_worn_arm',
        type: 'texture',
        path: '/textures/wood_table_worn_4k/textures/wood_table_worn_arm_4k.jpg'
    },
    {
        name: 'wood_table_worn_nor',
        type: 'texture',
        path: '/textures/wood_table_worn_4k/textures/wood_table_worn_nor_gl_4k.jpg'
    },


    {
        name: 'leather_white_diff',
        type: 'texture',
        path: '/textures/leather_white_4k/textures/leather_white_diff_4k.jpg'
    },
    {
        name: 'leather_white_arm',
        type: 'texture',
        path: '/textures/leather_white_4k/textures/leather_white_arm_4k.jpg'
    },
    {
        name: 'leather_white_nor',
        type: 'texture',
        path: '/textures/leather_white_4k/textures/leather_white_nor_gl_4k.jpg'
    },

    // {
    //     name: 'plywood_diff',
    //     type: 'texture',
    //     path: '/textures/plywood_4k/textures/plywood_diff_4k.png'
    // },
    // {
    //     name: 'plywood_arm',
    //     type: 'texture',
    //     path: '/textures/plywood_4k/textures/plywood_arm_4k.png'
    // },
    // {
    //     name: 'plywood_nor',
    //     type: 'texture',
    //     path: '/textures/plywood_4k/textures/plywood_nor_gl_4k.png'
    // },

    // {
    //     name: 'denim_fabric_diff',
    //     type: 'texture',
    //     path: '/textures/denim_fabric_1k/textures/denim_fabric_diff_1k.png'
    // },
    // {
    //     name: 'denim_fabric_arm',
    //     type: 'texture',
    //     path: '/textures/denim_fabric_1k/textures/denim_fabric_arm_1k.png'
    // },
    // {
    //     name: 'denim_fabric_nor',
    //     type: 'texture',
    //     path: '/textures/denim_fabric_1k/textures/denim_fabric_nor_gl_1k.png'
    // },

    {
        name: 'book_pattern_diff',
        type: 'texture',
        path: '/textures/book_pattern_1k/textures/book_pattern_col1_1k.jpg'
    },
    {
        name: 'book_pattern_arm',
        type: 'texture',
        path: '/textures/book_pattern_1k/textures/book_pattern_arm_1k.jpg'
    },
    {
        name: 'book_pattern_nor',
        type: 'texture',
        path: '/textures/book_pattern_1k/textures/book_pattern_nor_gl_1k.jpg'
    },




    {
        name: 'fabric_pattern_05_ao',
        type: 'texture',
        path: '/textures/fabric_pattern_05/fabric_pattern_05_ao_1k.jpg'
    },
    {
        name: 'fabric_pattern_05_arm',
        type: 'texture',
        path: '/textures/fabric_pattern_05/fabric_pattern_05_arm_1k.jpg'
    },
    {
        name: 'fabric_pattern_nor',
        type: 'texture',
        path: '/textures/fabric_pattern_05/fabric_pattern_05_nor_gl_1k.jpg'
    },
    {
        name: 'fabric_pattern_05_col_01',
        type: 'texture',
        path: '/textures/fabric_pattern_05/fabric_pattern_05_col_01_1k.jpg'
    },
    {
        name: 'fabric_pattern_05_col_02',
        type: 'texture',
        path: '/textures/fabric_pattern_05/fabric_pattern_05_col_02_1k.jpg'
    },
    {
        name: 'fabric_pattern_05_col_03',
        type: 'texture',
        path: '/textures/fabric_pattern_05/fabric_pattern_05_col_03_1k.jpg'
    },
    
    {
        name: 'perlin_noise',
        type: 'texture',
        path: '/textures/noise/perlin.png'
    },

    // {
    //     name: 'pjw2',
    //     type: 'gltfModel',
    //     path: '/pjw.glb'
    // },
    {
        name: 'ban_sign',
        type: 'texture',
        path: '/textures/ban/ban.png'
        // path: `${r2_url}/${r2_obj}`
    },
    {
        name:'bgm',
        type:'sound',
        path:'/sounds/orlog-bgm.mp3'
    },
    {
        name:'dice-rolling',
        type:'sound',
        path:'/sounds/dice/dice-rolling.mp3'
    },
    {
        name:'circle01',
        type:'texture',
        path:'/textures/circle/circle01.png'

    },
    {
        name:'particle_star_06',
        type:'texture',
        path:'/textures/particle/star_06.png'
    }

]