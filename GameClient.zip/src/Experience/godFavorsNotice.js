export default {
    "Frigg" : "Select dices to re-roll.",
    "Loki" : "Select dices to ban.",
    "Odin" : "Select health tokens to sacrifice.",
    "Tyr" : "Select health tokens to sacrifice."
}