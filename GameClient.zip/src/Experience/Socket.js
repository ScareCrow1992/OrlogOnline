import EventEmitter from "./Utils/EventEmitter.js";


export default class Socket extends EventEmitter{
    constructor(online){
        super()

        // console.log(online)
        this.ws = online.webSocket
        this.partnerbird
        // console.log(this.ws)

        this.ws.onmessage = (event) =>{
            this.partnerbird.Transport(event.data)
        }

        
        this.ws.onerror = (event) =>{
            console.log(event)
        }


        // this.ws.on('message', data=>{
        //     console.log(data)
        //     // switch(data.type){
        //     //     case "GodFavorPhaseOn":
        //     //         break;

        //     //         case 
        //     // }
        // })



        // trigger from server
        // this.trigger("GodFavorPhaseOn")

        // this.trigger("initial-game", [text, duration, first])

        // this.trigger("old-phase-end", [phase])

        // this.trigger("new-phase-start", [phase])

    }

    send(data) {
        if (this.ws.readyState == 1)
            this.ws.send(data)

    }



    CallFunction(data){
        let sync = data.sync
        let name = data.function
        let params = data.params



        if(sync == true){

        }

    }









    // trigger to server
    BellPushed(player){
        this.ws.send(player)
    }

    objectSelected(obj){
        this.ws.send(obj)
    
    }

}
