import * as THREE from 'three'
import Experience from '../Experience.js'
import gsap from 'gsap';
import TokenEffect from './TokenEffect.js'



export default class Token {
    constructor(pos, playerInfo) {
        this.experience = new Experience()
        this.scene = this.experience.scene
        this.resources = this.experience.resources
        this.geometryManager = this.experience.geometry
        this.debug = this.experience.debug


        this.setTexture()
        this.setGeometry()
        this.setMaterial()
        this.setMesh(pos)
        // this.setDebug()



    }

    setGeometry() {
        this.geometry = this.geometryManager.items.token;
    }


    setTexture() {
        // this.textures = {}

        // this.textures.color = this.resources.items.towelTexture
        // this.textures.color.encoding = THREE.sRGBEncoding
        // this.textures.color.repeat.set(5, 5)
        // this.textures.color.wrapS = THREE.RepeatWrapping
        // this.textures.color.wrapT = THREE.RepeatWrapping

        this.AOmap = this.resources.items.godsymbolAO
        this.AOmap.encoding = THREE.sRGBEncoding

        this.AOmap2 = this.resources.items.godsymbolAO2
        this.AOmap2.encoding = THREE.sRGBEncoding

        this.displacementMap = this.resources.items.godsymbolDisp2
        this.displacementMap.encoding = THREE.sRGBEncoding

        this.normalMap = this.resources.items.godsymbolNormal2
        this.normalMap.encoding = THREE.sRGBEncoding

        this.noiseDiffuse = this.resources.items.godsymbolNoise
        this.noiseDiffuse.encoding = THREE.sRGBEncoding

        this.noiseDiffuse1 = this.resources.items.godsymbolDiffuse
        this.noiseDiffuse1.encoding = THREE.sRGBEncoding

    }


    setMaterial() {
        this.materials = [
            new THREE.MeshStandardMaterial({ color: "#e0b000" }),
            new THREE.MeshStandardMaterial({ color: "#e0b000" }),
            new THREE.MeshStandardMaterial({ color: "#e0b000", metalnessMap : this.noiseDiffuse1, aoMap : this.AOmap2, normalMap: this.normalMap, displacementMap: this.displacementMap, displacementScale : 0.2, displacementBias :0 }),
            new THREE.MeshStandardMaterial({ color: "#e0b000", metalnessMap : this.noiseDiffuse1, aoMap : this.AOmap2, normalMap: this.normalMap, displacementMap: this.displacementMap, displacementScale : 0.2, displacementBias :0 }),
            new THREE.MeshStandardMaterial({ color: "#e0b000" }),
            new THREE.MeshStandardMaterial({ color: "#e0b000" }),
        ];

        this.materials.forEach(mat => {
            mat.metalness= 0.95;
            mat.roughness = 0.01;
            mat.flatShading = false;
            mat.transparent = true;
            mat.opacity = 0.0;
        })

        this.materials[2].displacementBias = -0.055
        this.materials[3].displacementBias = +0.055
    }

    setMesh(pos) {
        this.mesh = new THREE.Mesh(this.geometry, this.materials);
        // this.mesh.castShadow = true;
        // this.mesh.receiveShadow = true;
        this.mesh.position.copy(pos);
        // this.mesh.rotation.x += Math.PI
        this.mesh.geometry.computeVertexNormals()
        this.scene.add(this.mesh)
        this.effect = new TokenEffect(this.mesh.position)
        // console.log(this.effect);
        this.mesh.attach(this.effect.mesh)

        // console.log(this.mesh)

    }


    
    initialMove(goal){

        let anim = gsap.timeline()
        let fromPosition = this.mesh.position.clone()
        let fromHeight = fromPosition.y + 1.0

        anim.to(this.effect.material, {duration : 0.4, ease:"none", opacity : 1, onStart : ()=>{this.effect.ToggleLight()}})
        anim.to(this.mesh.position, {duration : 0.6, ease: "none", y : fromHeight}, "<")

        anim.to(this.mesh.position, {duration : 0.6, ease: "none", x : goal.x, y : goal.y, z : goal.z})

        anim.to(this.mesh.material, {duration : 0.3, ease: "none", opacity : 1})
        anim.to(this.effect.material, {duration : 0.8, ease: "none", opacity : 0, onComplete:()=>{this.effect.ToggleLight()}})
    
        // anim.then(()=>{console.log("move end")})
        return anim;
    }

    slideMove(goal){
        let anim = gsap.timeline()
        anim.to(this.effect.material, {delay : 0.2, duration : 0.4, ease: "none", opacity:1, onStart : ()=>{this.effect.ToggleLight()}})
        anim.to(this.mesh.position, {delay : 0.15, duration : 0.4, ease: "none", x : goal.x, y : goal.y, z : goal.z})
        anim.to(this.effect.material, {delay: 0.15, duration: 0.4, ease: "none", opacity:0, onComplete : ()=>{this.effect.ToggleLight()}})

        return anim
    }



    GetPosition(){
        return this.mesh.position
    }


    Spend(){
        let anim = gsap.timeline()
        .to(this.effect, {onStart : ()=>{this.effect.ToggleLight()}})
        .to(this.effect.material, {duration: 0.5, ease:"none", opacity : 1})
        .to(this.effect.material, {delay : 1.0 ,duration: 0.5, ease:"none", opacity : 0})
        .to(this.mesh.material, {duration: 0.5, ease:"none", opacity : 0}, "<")
        .to(this.effect, {onComplete : ()=>{this.effect.ToggleLight()}})
        .then(()=>{this.destroy()})

        return anim
    }


    destroy(){
        this.materials.forEach(mat => {
            mat.dispose()
        })

        this.effect.destroy()

        // console.log(window.experience)
        this.scene.remove(this.mesh)
    }


    battleEnd(){
        console.log("stealed!")

        // 상대 팀 쪽의 스택에 넣은 후, 가야할 장소를 알아낸다.
    }


    setDebug(){
        if (this.debug.active) {
            this.debugFolder = this.debug.ui.addFolder(`Token`);

            this.debugFolder
                .addColor(this.materials[2], "color")

            this.debugFolder
                .addColor(this.materials[2], "emissive")

            this.debugFolder
                .add(this.materials[2], 'displacementScale')
                .name('symbol displacement Scale')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.materials[2], 'displacementBias')
                .name('symbol displacement Bias')
                .min(-2)
                .max(2)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.materials[2], 'aoMapIntensity')
                .name('aoMapIntensity')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.materials[2].normalScale, 'x')
                .name('normal Scale X')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.materials[2].normalScale, 'y')
                .name('normal Scale Y')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.materials[2], 'metalness')
                .name('metalness')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.materials[2], 'roughness')
                .name('roughness')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()


            this.debugFolder
                .add(this.mesh.position, 'x')
                .name('position X')
                .min(-10)
                .max(10)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.mesh.position, 'y')
                .name('position Y')
                .min(-1)
                .max(5)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.mesh.position, 'z')
                .name('position Z')
                .min(-10)
                .max(10)
                .step(0.001)
                .listen()

        }

    }

}