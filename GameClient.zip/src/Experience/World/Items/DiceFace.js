import * as THREE from 'three'
import Experience from '../../Experience.js'
import gsap from 'gsap';
import DiceMark from './DiceMark.js'


// 주인이 누구인지, 자신이 god favor 능력 연관인지, 어느 면에 있는지 등은 전혀 관여하지 않는다.
/*
faceInfo = {
    right : {weapon : "axe", token : true}
    ...
    }
*/
export default class DiceFace {
    constructor(faceInfo, faceDir) {
        this.experience = new Experience()
        this.scene = this.experience.scene
        this.resources = this.experience.resources
        this.debug = this.experience.debug
        this.materialManager = this.experience.material
        // console.log(this.materialManager)

        // Material
        //"tokenMark"
        //"axeMark"
        //"arrowMark"

        // Geometry
        // 

        


        this.itemPrefab;    // new Weapon()
        // instance of this.weaponPrefab
        this.weaponType = faceInfo.weapon;    // "arrow", "axe", "shield", "steal", "token" ...
        // this.isToken;   // true, false

        this.isToken = faceInfo.token;

        this.weaponMeshes = []
        this.tokenMesh = null
        this.faceDir = faceDir

        this.setDiceMark(faceInfo, faceDir)
        if (this.isToken == true)
            this.setTokenMesh()


        this.diceMark;
        this.godFavorDiceMarks = []
        this.isGodFavorOn = false
    }

    get position(){
        return this.obj.position
    }


    setDiceMark(faceInfo, faceDir) {
        this.obj = new THREE.Object3D()
        this.obj.lookAt(this.faceDir)
        this.obj.position.copy(this.faceDir)
        this.obj.position.multiplyScalar(0.5)

        this.diceMark = new DiceMark(faceInfo.weapon);
        this.obj.add(this.diceMark.weaponMark)
        


        // let newMark = new THREE.Mesh(new THREE.PlaneGeometry(), this.materialManager.items[`${this.weaponType}Mark`].clone())
        // newMark.lookAt(this.faceDir)
        // newMark.position.copy(this.faceDir)
        // // newMark.scale.set(1.4, 1.4, 1.4);
        // newMark.position.multiplyScalar(0.5)

        // this.weaponMeshes.push(newMark)
    }


    setTokenMesh() {
        let newToken;
        newToken = new THREE.Mesh(new THREE.PlaneGeometry(), this.materialManager.items[`tokenMark`].clone())
        newToken.lookAt(this.faceDir)
        newToken.position.copy(this.faceDir)
        newToken.position.multiplyScalar(0.502)
        newToken.scale.set(.90, .90, .90);
        this.tokenMesh = newToken
    }


    getMarks() {
        if (this.isGodFavorOn)
            return this.godFavorDiceMarks
        else
            return [this.diceMark]
    }


    ConvertToGodfavorMarks(cnt, weaponName, color, transforms){
        this.isGodFavorOn = true
        // console.log(cnt)
        // console.log(weaponName)


        // 색상, 무기 모델명
        this.godFavorDiceMarks = []
        let promises = []

        for(let index = 0; index < cnt; index++){
            let godFavorDiceMark = new DiceMark(this.weaponType, color);
            this.godFavorDiceMarks.push(godFavorDiceMark)
            this.obj.add(godFavorDiceMark.weaponMark)
            godFavorDiceMark.weaponMark.applyMatrix4(transforms[index])

            godFavorDiceMark.weaponMark.material.depthTest = false
            // godFavorDiceMark.weaponMark.layers.toggle(1)
            godFavorDiceMark.weaponMark.renderOrder = 4


            let prom = godFavorDiceMark.EngravedAnimation()
            promises.push(prom)
            // godFavorDiceMark.weaponMark.material.color.set(color)
            // console.log(godFavorDiceMark.weaponMark)

            this.diceMark.SetPosition(0,0,-0.5)
            
        }

        let allPromise = Promise.all(promises)

        // let promise = this.diceMark.EngravedAnimation()
        return [allPromise, ()=>{this.ResetDiceMark()}]
        // round reset시 상태를 되돌리는 callback 함수를 반환
    }


    ResetDiceMark(){
        this.isGodFavorOn = false

        this.godFavorDiceMarks.forEach(diceMark=>{
            diceMark.destroy()
            this.obj.remove(diceMark.weaponMark)
        })

        this.diceMark.SetPosition(0,0,0.02)

        
        this.godFavorDiceMarks = []
    }


    Disappear(){
        this.ResetDiceMark()
        this.diceMark.destroy();
        this.obj.remove(this.diceMark.weaponMark)
        if(this.tokenMesh != null){
            this.tokenMesh.material.dispose()
            this.obj.remove(this.tokenMesh)
        }
    }


    // summonWeapon(){

    // }

    // attackTo(target){
        
    // }


    // getWeaponType() {
    //     return this.weaponType;
    // }

    // getItem() {

    // }


    _DBG_setFaceColor(color){
        this.diceMark.weaponMark.material.color.copy(color)
        // console.log(color)
        // this.weaponMeshes.forEach(mesh=>{
        //     console.log(color)
        //     mesh.material.color.copy(color)
        // })
    }

}