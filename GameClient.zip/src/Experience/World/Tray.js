import * as THREE from 'three'
import Experience from '../Experience.js'
import { gsap } from 'gsap'


export default class Tray {
    constructor() {
        this.experience = new Experience()
        this.scene = this.experience.scene
        this.resources = this.experience.resources
        this.debug = this.experience.debug
        this.setGeometry()
        this.setTexture()
        this.setMaterial()
        this.setMesh();
        // this.setDebug()
    }



    setGeometry() {

        let radius = 2.8
        let thickness = 0.1
        
        this.outerWallGeometry = new THREE.CylinderGeometry(radius + thickness, radius + thickness, 2.7, 32, 4, true);
        // this.outerWallGeometry.openEnded = true;
        this.innerWallGeometry = new THREE.CylinderGeometry(radius - thickness, radius - thickness, 2.7, 32, 4, true);
        // this.innerWallGeometry.openEnded = true;
        this.thicknessGeometry = new THREE.RingGeometry(radius - thickness, radius + thickness, 32, 1)
        this.flatGeometry = new THREE.CylinderGeometry(radius - thickness, radius - thickness, thickness, 32, 3);

        //RingGeometry


        // CylinderGeometry





        // this.flatGeometry = new THREE.CylinderGeometry(2.6, 2.6, 0.1, 32, 3);

        // const points = [];
        // const radius = 25;
        // const strength = 10;

        // points.push(new THREE.Vector2(radius / strength, 0));
        // points.push(new THREE.Vector2(radius / strength, 3 / strength));
        // points.push(new THREE.Vector2(radius / strength, 6 / strength));
        // points.push(new THREE.Vector2(radius / strength, 9 / strength));
        // points.push(new THREE.Vector2(radius / strength, 12 / strength));

        // points.push(new THREE.Vector2((radius + 2) / strength, 12 / strength));
        // points.push(new THREE.Vector2((radius + 2) / strength, 9 / strength));
        // points.push(new THREE.Vector2((radius + 2) / strength, 6 / strength));
        // points.push(new THREE.Vector2((radius + 2) / strength, 3 / strength));
        // points.push(new THREE.Vector2((radius + 2) / strength, 0));

        // this.wallGeometry = new THREE.LatheGeometry(points, 32, Math.PI);
        // this.wallGeometry.computeVertexNormals()

        // const material = new THREE.MeshBasicMaterial( {color: 0xffff00} );
        // const cylinder = new THREE.Mesh( geometry, material );


        // this.geometry = new THREE.BoxGeometry(3, 3, 3);
        // this.geometry = new THREE.BoxGeometry(1,1,1,20,20,20)
    }


    setTexture() {
        // let textureName = ["textureAO", "textureArm", "textureDiffuse", "textureNormal", "textureRoughness"]

        // this.textureAO = this.resources.items.wood_table_001_ao
        // this.textureArm = this.resources.items.wood_table_001_arm
        // this.textureDiffuse = this.resources.items.wood_table_001_diff
        // this.textureNormal = this.resources.items.wood_table_001_nor
        // this.textureRoughness = this.resources.items.wood_table_001_rough

        // textureName.forEach(texture => {
        //     this[`${texture}`].encoding = THREE.sRGBEncoding;
        //     this[`${texture}`].repeat.set(1, 1);
        //     this[`${texture}`].wrapS = THREE.RepeatWrapping
        //     this[`${texture}`].wrapT = THREE.RepeatWrapping
        //     this[`${texture}`].anisotropy = 16;
        // })


        let textureName = ["textureArm", "textureDiffuse", "textureNormal"]
        this.textureDiffuse = this.resources.items.wood_table_worn_diff
        this.textureArm = this.resources.items.wood_table_worn_arm
        this.textureNormal = this.resources.items.wood_table_worn_nor

        textureName.forEach(texture => {
            this[`${texture}`].encoding = THREE.sRGBEncoding;
            this[`${texture}`].repeat.set(1, 1);
            this[`${texture}`].wrapS = THREE.RepeatWrapping
            this[`${texture}`].wrapT = THREE.RepeatWrapping
            this[`${texture}`].anisotropy = 16;
        })

    }

    /*
    const material = new THREE.MeshStandardMaterial( {
        map: imgTexture,
        bumpMap: imgTexture,
        bumpScale: bumpScale,
        color: diffuseColor,
        metalness: beta,
        roughness: 1.0 - alpha,
        envMap: index % 2 === 0 ? null : texture
    } );
    */


    setMaterial() {
        // const gamma = 0.9;
        // const alpha = 0.2;
        // const diffuseColor = new THREE.Color().setHSL( alpha, 0.2, gamma );
        // this.material = new THREE.MeshStandardMaterial({
        //     map: this.texture,
        //     bumpMap: this.texture,
        //     bumpScale: 1.0,
        //     color: diffuseColor,
        //     metalness: 0.1,
        //     roughness: 1.0 - alpha,
        //     normalMap: this.normalMap,
        //     opacity : alpha
        // });
        // // this.material.opacity = alpha;
        // this.material.side = THREE.DoubleSide;
        // this.material.flatshading = false;

        this.material = new THREE.MeshStandardMaterial({
            map: this.textureDiffuse,
            normalMap: this.textureNormal,
            metalnessMap: this.textureArm,
            roughnessMap: this.textureArm,
            aoMap: this.textureArm
        })

        this.material.flatshading = false;
        this.material.side = THREE.DoubleSide;

    }


    setMesh() {        
        this.outerWallMesh = new THREE.Mesh(this.outerWallGeometry, this.material)
        this.innerWallMesh = new THREE.Mesh(this.innerWallGeometry, this.material)
        this.thicknessMesh = new THREE.Mesh(this.thicknessGeometry, this.material)
        this.thicknessMesh.position.y = 1.35
        this.thicknessMesh.rotation.x -= Math.PI/2;
        this.flatGeometry = new THREE.Mesh(this.flatGeometry, this.material)

        
        this.mesh = new THREE.Group();
        this.mesh.add(this.outerWallMesh)
        this.mesh.add(this.innerWallMesh)
        this.mesh.add(this.thicknessMesh)
        this.mesh.add(this.flatGeometry)

        // this.outerWallMesh.receiveShadow = true;
        this.outerWallMesh.castShadow = true;

        this.innerWallMesh.receiveShadow = true;
        this.innerWallMesh.castShadow = true;

        // this.thicknessMesh.receiveShadow = true;
        // this.thicknessMesh.castShadow = true;

        // this.flatGeometry.receiveShadow = true;
        // this.flatGeometry.castShadow = true;

        this.scene.add(this.mesh)




        // this.flatMesh = new THREE.Mesh(this.flatGeometry, this.material);
        // this.wallMesh = new THREE.Mesh(this.wallGeometry, this.material);

        // this.flatMesh.receiveShadow = true;
        // this.flatMesh.castShadow = true;

        // this.wallMesh.receiveShadow = true;
        // this.wallMesh.castShadow = true;

        // this.mesh = new THREE.Group();
        // this.mesh.add(this.flatMesh);
        // this.mesh.add(this.wallMesh);
        // this.scene.add(this.mesh);

    }


    Move(pos){
        return gsap.to(this.mesh.position, {duration : 0.3, ease:"none", z : pos.z})
    }



    setDebug() {
        if (this.debug.active) {
            
            this.debugFolder = this.debug.ui.addFolder(`Tray`);


            this.debugFolder
                .addColor(this.material, "color")

            this.debugFolder
                .addColor(this.material, "emissive")

            this.debugFolder
                .add(this.material, 'displacementScale')
                .name('symbol displacement Scale')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material, 'displacementBias')
                .name('symbol displacement Bias')
                .min(-2)
                .max(2)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material, 'aoMapIntensity')
                .name('aoMapIntensity')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material.normalScale, 'x')
                .name('normal Scale X')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material.normalScale, 'y')
                .name('normal Scale Y')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material, 'metalness')
                .name('metalness')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material, 'roughness')
                .name('roughness')
                .min(-1)
                .max(2)
                .step(0.001)
                .listen()


            this.debugFolder
                .add(this.mesh.position, 'x')
                .name('position X')
                .min(-10)
                .max(10)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.mesh.position, 'y')
                .name('position Y')
                .min(-1)
                .max(5)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.mesh.position, 'z')
                .name('position Z')
                .min(-10)
                .max(10)
                .step(0.001)
                .listen()



        }

    }



}