import * as THREE from 'three'
import Experience from '../Experience.js'

export default class Towel {
    constructor() {
        this.experience = new Experience()
        this.scene = this.experience.scene
        this.resources = this.experience.resources
        this.debug = this.experience.debug

        this.setGeometry()
        this.setTextures()
        this.setMaterial()
        this.setMesh()
        // this.setDebug()
    }

    setGeometry() {
        this.geometry = new THREE.PlaneGeometry( 35, 30, 64, 64 );
    }

    setTextures() {
        this.textures = {}

        // this.textures.color = this.resources.items.towelTexture
        // this.textures.color.encoding = THREE.sRGBEncoding
        // this.textures.color.repeat.set(5, 5)
        // this.textures.color.wrapS = THREE.RepeatWrapping
        // this.textures.color.wrapT = THREE.RepeatWrapping

        // let textureName = ["textureAO", "textureArm", "textureDiffuse", "textureNormal", "textureRoughness"]
        
        // this.textureAO = this.resources.items.denmin_fabric_02_ao
        // this.textureArm = this.resources.items.denmin_fabric_02_arm
        // this.textureDiffuse = this.resources.items.denmin_fabric_02_diff
        // this.textureNormal = this.resources.items.denmin_fabric_02_nor
        // this.textureRoughness = this.resources.items.denmin_fabric_02_rough

        let textureName = ["textureArm", "textureNormal", "textureDiffuse"]

        // this.textureArm = this.resources.items.book_pattern_arm
        // this.textureDiffuse = this.resources.items.book_pattern_diff
        // this.textureNormal = this.resources.items.book_pattern_nor

        this.textureArm = this.resources.items.fabric_pattern_05_arm
        this.textureDiffuse = this.resources.items.fabric_pattern_05_col_01
        this.textureNormal = this.resources.items.fabric_pattern_nor



        textureName.forEach(texture => {
            this[`${texture}`].encoding = THREE.sRGBEncoding;
            this[`${texture}`].repeat.set(4, 4);
            this[`${texture}`].wrapS = THREE.RepeatWrapping
            this[`${texture}`].wrapT = THREE.RepeatWrapping
            this[`${texture}`].anisotropy = 16;
            // this[`${texture}`].rotation = Math.PI / 2
        })


    }

    setMaterial() {
        // this.material = new THREE.MeshStandardMaterial({
        //     map: this.textures.color
        // })

        // this.material = new THREE.MeshStandardMaterial({
        //     map : this.textureDiffuse,
        //     normalMap : this.textureNormal,
        //     aoMap : this.textureAO,
        //     roughnessMap : this.textureRoughness,
        //     bumpScale: 0.0005
        // })

        this.material = new THREE.MeshStandardMaterial({
            map : this.textureDiffuse,
            normalMap : this.textureNormal,
            normalScale : new THREE.Vector2(0.5, 0.5),
            aoMap : this.textureArm,
            roughnessMap : this.textureArm,
            bumpScale: 0.0005,
            metalness : 0.2,
            roughness : 2.1
        })

    }

    setMesh() {
        this.mesh = new THREE.Mesh(this.geometry, this.material)
        this.mesh.rotation.x = - Math.PI * 0.5
        // this.mesh.rotation.z = - Math.PI * 0.5
        this.mesh.receiveShadow = true
        this.scene.add(this.mesh)
    }


    setDebug(){
        if (this.debug.active) {
            
            this.debugFolder = this.debug.ui.addFolder(`Table`);


            this.debugFolder
                .addColor(this.material, "color")

            this.debugFolder
                .addColor(this.material, "emissive")
                
            this.debugFolder
            .add(this.material, "emissiveIntensity")
            .name('emissiveIntensity')
            .min(0)
            .max(1)
            .step(0.001)
            .listen()

            this.debugFolder
                .add(this.material, 'displacementScale')
                .name('symbol displacement Scale')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material, 'displacementBias')
                .name('symbol displacement Bias')
                .min(-2)
                .max(2)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material, 'aoMapIntensity')
                .name('aoMapIntensity')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material.normalScale, 'x')
                .name('normal Scale X')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material.normalScale, 'y')
                .name('normal Scale Y')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material, 'metalness')
                .name('metalness')
                .min(0)
                .max(1)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.material, 'roughness')
                .name('roughness')
                .min(0)
                .max(3)
                .step(0.001)
                .listen()


            this.debugFolder
                .add(this.mesh.position, 'x')
                .name('position X')
                .min(-10)
                .max(10)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.mesh.position, 'y')
                .name('position Y')
                .min(-1)
                .max(5)
                .step(0.001)
                .listen()

            this.debugFolder
                .add(this.mesh.position, 'z')
                .name('position Z')
                .min(-10)
                .max(10)
                .step(0.001)
                .listen()



        }

    }

}