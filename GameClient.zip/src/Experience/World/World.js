import * as THREE from 'three'
// import PhysicsTest from '../PhysicsTest.js'

import Experience from '../Experience.js'
import Environment from './Environment.js'
import Floor from './Floor.js'
import Fox from './Fox.js'
// import Dice from './Dice.js'
import Dice from './Items/Dice.js'
import TokenDice from './Items/TokenDice.js'

import GodFavor from './GodFavor.js'
import GodPiece from './GodPiece.js'
import Tray from './Tray.js'
import Towel from './Towel.js'
// import HealthStone from './HealthStone.js'
import HealthStone from './Items/HealthStone.js'
import TurnEndButton from './TurnEndButton.js'
import TurnEndButtonDBG from './TurnEndButtonDBG.js'
import Weapon from './Model/Weapon.js'

import Model from './Items/Model.js'
import FlipCoin from './FlipCoin.js'

import Avatar from './Avatar.js'
// import {godFavorsAction, godFavorsExtraAction} from '../godFavorsAction.js'

import FadeDisappear from '../Shaders/Materials/FadeDisappear.js'
import ParticleSystem from '../Particle/ParticleSystem.js'
import EnergyMaterial from '../Shaders/Materials/EnergyMaterial.js'

import Stamp from './Items/Stamp.js'

import gsap from 'gsap'


// import { TransformControls } from 'three/examples/jsm/controls/TransformControls.js'


let sphere_material, mask_material, outline_material, energy_material

const diceFaceInfo = [{
    "right" : {weapon : "axe", token : false},
    "left" : {weapon : "shield", token : false},
    "top" : {weapon : "axe", token : false},
    "bottom" : {weapon : "helmet", token : false},
    "front" : {weapon : "arrow", token : true},
    "back" : {weapon : "steal", token : true}},

{
    "right" : {weapon : "axe", token : false},
    "left" : {weapon : "shield", token : true},
    "top" : {weapon : "axe", token : false},
    "bottom" : {weapon : "steal", token : true},
    "front" : {weapon : "arrow", token : false},
    "back" : {weapon : "helmet", token : false}
},

{
    "right" : {weapon : "axe", token : false},
    "left" : {weapon : "arrow", token : true},
    "top" : {weapon : "axe", token : false},
    "bottom" : {weapon : "helmet", token : true},
    "front" : {weapon : "steal", token : false},
    "back" : {weapon : "shield", token : false}
},

{
    "right" : {weapon : "arrow", token : false},
    "left" : {weapon : "shield", token : false},
    "top" : {weapon : "axe", token : false},
    "bottom" : {weapon : "helmet", token : true},
    "front" : {weapon : "steal", token : true},
    "back" : {weapon : "axe", token : false}
},

{
    "right" : {weapon : "axe", token : false},
    "left" : {weapon : "shield", token : true},
    "top" : {weapon : "axe", token : false},
    "bottom" : {weapon : "helmet", token : false},
    "front" : {weapon : "steal", token : false},
    "back" : {weapon : "arrow", token : true}

},

{
    "right" : {weapon : "axe", token : false},
    "left" : {weapon : "shield", token : true},
    "top" : {weapon : "axe", token : false},
    "bottom" : {weapon : "arrow", token : false},
    "front" : {weapon : "steal", token : false},
    "back" : {weapon : "helmet", token : true}

}
]



export default class World {
    constructor() {
        this.experience = new Experience()
        this.scene = this.experience.scene
        this.resources = this.experience.resources
        this.gameObjects = {}   // "mesh id" : "object"

        this.playerInteractableObjects = [];

        this.top_card_pick_ancnor = new THREE.Vector3(-3.75, 0, -4.25 + 0.5)
        this.bottom_card_pick_anchor = new THREE.Vector3(2.25, 0, 5.0 + 0.5)
        // gsap.ticker.lagSmoothing(false);

        // document.addEventListener("visibilitychange", function() {
        //     if (document.hidden){
        //         console.log("hidden")
        //     } else {
        //         console.log("display")
        //         gsap.ticker.lagSmoothing(200, 33);
        //     }
        // });

        // let r2_url = "https://pub-0256486a954c46a6b1aa910ba51cca8f.r2.dev"
        // let r2_obj = "ban_.png"

        
        // let r2_url = "https://threejs.org/examples/textures"
        // let r2_obj = "uv_grid_opengl.jpg"

        // let textureLoader = new THREE.TextureLoader()

        // textureLoader.load(
        //     `${r2_url}/${r2_obj}`,
        //     (file) => { console.log(file) }
        // )



        // Wait for resources
        this.resources.on('ready', () => {

       



            // let ban_mat = new THREE.MeshBasicMaterial({map : this.resources.items["ban_sign"], transparent : true, color : "red"})
            // let ban_geo = new THREE.PlaneGeometry()
            // let ban_mesh = new THREE.Mesh(ban_geo, ban_mat)
            // ban_mesh.position.y += 1
            // ban_mesh.scale.set(2,2,2)
            // ban_mesh.rotateX(-Math.PI/2)
            // this.scene.add(ban_mesh)

            this.stamp = new Stamp()
            this.stamp.PositionToOrigin()


            // let stamp = this.resources.items.stampModel2.scenes[0].children[0]
            // this.scene.add(stamp)

            // let stamp = this.resources.items.stampModel3.scenes[0].children[0]
            // this.scene.add(stamp)



            // let camera = this.experience.camera.instance
            // let renderer = this.experience.renderer.instance


            // let geo_ = new THREE.BoxGeometry(1,1,1)
            // let mat_ = new THREE.MeshStandardMaterial({color : new THREE.Color("sienna")})

            // let box_mesh_0 = new THREE.Mesh(geo_, mat_)
            // box_mesh_0.position.set(-3.75, 0, -4.25 + 0.5)

            // let control_0 = new TransformControls( camera, renderer.domElement );
            // control_0.attach(box_mesh_0)

            // let box_mesh_1 = new THREE.Mesh(geo_, mat_)
            // box_mesh_1.position.set(2.25, 0, 5.0 + 0.5)
            // let control_1 = new TransformControls( camera, renderer.domElement );
            // control_1.attach(box_mesh_1)
            
            

            // this.scene.add(box_mesh_0)
            // this.scene.add(box_mesh_1)

            // this.scene.add(control_0)
            // this.scene.add(control_1)

            // window.addEventListener("keydown", e=>{
            //     if(e.key == "c"){
            //         console.log(box_mesh_0.position)
            //         console.log(box_mesh_1.position)
            //     }
            // })







            // dark aura


            const sphere_geometry = new THREE.IcosahedronGeometry(0.5, 3);
            
            sphere_material = new THREE.MeshStandardMaterial({
                map: this.resources.items.diceArrowTexture,
                color: 0x00cc22
            });

            energy_material = EnergyMaterial(sphere_material)
            console.log(energy_material)
            sphere_material.dispose();

            const sphere_mesh = new THREE.Mesh( sphere_geometry, energy_material );
            sphere_mesh.layers.enable(1)

            sphere_mesh.position.x += 6;
            sphere_mesh.position.y += 2;
            
            this.scene.add(sphere_mesh)


            // Particle
            // const sphere_geometry = new THREE.IcosahedronGeometry(0.5, 3);
            // sphere_material = new THREE.MeshStandardMaterial({
            //     map : this.resources.items.diceArrowTexture
            //     , color: 0x00cc22 });
            // [mask_material, outline_material] = FadeDisappear(sphere_material)
            // sphere_material.dispose();

            // const sphere_mesh = new THREE.Mesh( sphere_geometry, mask_material );
            // const sphere_effect = new THREE.Mesh( sphere_geometry, outline_material );
            // sphere_effect.layers.enable(1)

            
            // this.particle = new ParticleSystem(sphere_geometry);

            // const sphere_group = new THREE.Group()
            // sphere_group.add(sphere_mesh)
            // sphere_group.add(sphere_effect)
            // sphere_group.add(this.particle.points)


            // this.scene.add( sphere_group );
            // sphere_group.position.y += 2;
            // sphere_group.position.x += 6;





            // let sprite_map = this.resources.items["circle01"]
            // let sprite_material = new THREE.SpriteMaterial( { map: sprite_map } );
            // sprite_material.color = new THREE.Color( 'skyblue' );
            // sprite_material.depthTest = false;
            // let sprite = new THREE.Sprite(sprite_material)
            // sprite.renderOrder = 5
            // sprite.scale.set(8, 8, 8)
            // sprite.position.x += 5;
            // this.scene.add(sprite)




            /*
            let circle_material = new THREE.MeshBasicMaterial({ map: this.resources.items["circle01"] })
            circle_material.transparent = true;
            circle_material.color = new THREE.Color(0x00ffff)
            let circle_plane = new THREE.Mesh(new THREE.PlaneGeometry(), circle_material)

            circle_plane.scale.set(8,8,8)
            circle_plane.position.x += 5;
            circle_plane.position.y += 4;
            circle_plane.position.z += 2;
            circle_plane.rotateX(-Math.PI / 4);
            circle_plane.layers.enable(1)

            this.scene.add(circle_plane)
            console.log(circle_plane)
            */



            // let table = this.resources.items["tableModel"]
            // console.log(table)
            // this.scene.add(table.scene)
            

            // this.scene.add(table.scenes[0])
            // this.scene.add(table.scenes[1])
            // this.scene.add(table.scenes[2])
            // this.scene.add(table.scenes[3])
            // table.scene.position.y -= 2.5
            // table.scene.rotation.y += Math.PI/2



            // let pjw = this.resources.items.pjw2.scene.children[0]
            // console.log(pjw)
            // this.scene.add(pjw)
            // pjw.scale.set(20,10,10)
            // console.log(pjw.material)
            // pjw.material.map.encoding = THREE.sRGBEncoding;
            // pjw.material.map.wrapS = THREE.RepeatWrapping
            // pjw.material.map.wrapT = THREE.RepeatWrapping
            // pjw.material.map.repeat.set(2, 2);
            // pjw.material.map.anisotropy = 16;


            // pjw.scene.children[0].position.y += 2

            this.flipCoin = new FlipCoin()
            this.experience.controller.flipCoin = this.flipCoin


            // let modelName = ["axe", "arrow", "helmet", "shield"]
            // modelName.forEach((name, index)=>{
            //     let model = new Model(name)
            //     model.mesh.position.x = index
            //     model.mesh.position.y = 1
            // })


            
            
            // let mjolnir2 = this.resources.items["mjolnir2Model"].scene.children[0]
            // console.log(this.resources.items["mjolnir2Model"].scene.children[0])
            // mjolnir2.scale.set(1,1,1)
            // mjolnir2.position.y +=4
            // mjolnir2.position.x +=4
            // mjolnir2.rotateX(-Math.PI)       
            // mjolnir2.layers.enable(1)
            // mjolnir2.material = new THREE.MeshStandardMaterial
            // ({transparent: true, color: "#00ffff", })
            // this.scene.add(mjolnir2)


            // let mjolnir = new Model("mjolnir")
            // this.scene.add(mjolnir)
            // mjolnir.SetPosition(new THREE.Vector3(0,4,0))
            // mjolnir.mesh.rotateX(Math.PI)

            
            // this.physics = new PhysicsTest();



            
            this.avatars = {
                top : new Avatar(-1),
                bottom : new Avatar(1)
            }

            this.experience.controller.avatars.top = this.avatars.top;
            // this.avatars.top.eventEmitter = this.experience.controller.eventEmitter

            this.experience.controller.avatars.bottom = this.avatars.bottom;
            // this.avatars.bottom.eventEmitter = this.experience.controller.eventEmitter


            /*
            let vec = new THREE.Vector3(0,1,0);
            let hammer = new Weapon("mjolnir", vec);
            hammer.mesh.position.x += 3;
            hammer.mesh.position.y += 3;
            hammer.mesh.position.z += 3;
            hammer.mesh.scale.set(1, 1, 1);
            hammer.material.opacity = 1;
            */

            // let axe = new Weapon("axe")
            // axe.SetPosition(new THREE.Vector3(0, 1.5, 0))

            // let helmet = new Weapon("helmet")
            // helmet.SetPosition(new THREE.Vector3(1, 1.5, 0))

            // let arrow = new Weapon("arrow")
            // arrow.SetPosition(new THREE.Vector3(2, 1.5, 0))

            // let shield = new Weapon("shield")
            // shield.SetPosition(new THREE.Vector3(-1, 1.5,0))

            // let bow = new Weapon("bow", new THREE.Vector3(-2, 1.5,0))
            
            this.towel = new Towel()

            // this.fox = new Fox()
            // this.fox.model.position.x -= 5;
            // this.fox.model.position.z -= 5;

            this.environment = new Environment()

            let sign = {
                top: -1,
                bottom: 1
            }

            let nTray = new Tray()
            nTray.mesh.position.z = sign["bottom"] * 6;
            this.avatars.bottom.tray.copy(nTray.mesh.position);
            this.avatars.bottom.bowl = nTray

            nTray = new Tray()
            nTray.mesh.position.z = sign["top"] * 6;
            this.avatars.top.tray.copy(nTray.mesh.position);
            this.avatars.top.bowl = nTray




            this.dices = []
            diceFaceInfo.forEach((faceInfo, index)=>{
                let dice = new Dice(faceInfo)
                this.dices.push(dice)
                this.gameObjects[`${dice.getID()}`] = dice;
                this.playerInteractableObjects.push(dice.mesh.mesh);
                this.avatars.bottom.diceDictionary[`${dice.getID()}`] = {obj : dice, index : index};

                let nPosition = new THREE.Vector3(
                    ((index % 3) - 1) * 1.5,
                    5,
                    (11.5 + (index % 2) * 1.5))
                dice.setPosition(nPosition)

                this.avatars.bottom.dices.push(dice);
            })


            diceFaceInfo.forEach((faceInfo, index)=>{
                let dice = new Dice(faceInfo)
                this.dices.push(dice)
                this.gameObjects[`${dice.getID()}`] = dice;
                this.playerInteractableObjects.push(dice.mesh.mesh);
                this.avatars.top.diceDictionary[`${dice.getID()}`] = {obj : dice, index : index};

                let nPosition = new THREE.Vector3(
                    ((index % 3) - 1) * 1.5,
                    5,
                    -(10.5 + (index % 2) * 1.5))
                dice.setPosition(nPosition)

                this.avatars.top.dices.push(dice);
            })


            // this.token_dices = []
            // let token_dices_type = ["normal", "hidden"]
            // token_dices_type.forEach((type, index) => {
            //     let token_dice = new TokenDice(type)
            //     this.token_dices.push(token_dice)

            //     let nPosition = new THREE.Vector3(
            //         (index - 0.5) * 2.5, 5, 14.5
            //     )

            //     token_dice.setPosition(nPosition)
            // })
            

            
            let players=["top", "bottom"]
        
            const godFavorNames = ["Baldr", "Bragi", "Brunhild", "Freyja", "Freyr", "Frigg", "Heimdall", "Hel", "Idun", "Loki", "Mimir", "Odin", "Skadi", "Skuld", "Thor", "Thrymr", "Tyr", "Ullr", "Var", "Vidar"];

            this.godFavors = {}

            
            players.forEach((player) => {
                this.godFavors[`${player}`] = {}
                let avatar = this.avatars[`${player}`]
                
                avatar.godFavorDictionary = {}
                godFavorNames.forEach((godFavorName, godFavorIndex) => {
                    let pos = new THREE.Vector3(-15 + 1.5 * godFavorIndex, 0, 20)

                    const godfavor = new GodFavor(
                        godFavorName,
                        pos,
                        this.experience.godFavorsInfo[`${godFavorName}`],
                        this.experience.godFavorsAction[`${godFavorName}`]
                    );
                    // avatar.godFavors = []
                    // avatar.godFavors.push(godfavor);

                    avatar.godFavorDictionary[`${godfavor.getID()}`] = { obj: godfavor, index: godFavorIndex }
                    this.playerInteractableObjects.push(godfavor.mesh);
                    this.gameObjects[godfavor.mesh.id] = godfavor;

                    // this.godFavors[`${player}`] = {}
                    this.godFavors[`${player}`][`${godFavorName}`] = godfavor

                })
                // for (let index = 0; index < 3; index++) {
                //     let godFavorName = godfavor_for_beginner[index];
                //     let newPosition = avatar.godFavorAnchor.clone()
                //     newPosition.x += 1.3 * index * avatar.anchorSign
                //     const godfavor = new GodFavor(godFavorName, newPosition, this.experience.godFavorsInfo[`${godFavorName}`], this.experience.godFavorsAction[`${godFavorName}`]);
                //     avatar.godFavors.push(godfavor);
                //     avatar.godFavorDictionary[`${godfavor.getID()}`] = {obj : godfavor, index : index}
                //     this.playerInteractableObjects.push(godfavor.mesh);
                //     this.gameObjects[godfavor.mesh.id] = godfavor;
                // }
            })
            



            // for (let index = 0; index < 3; index++) {
            //         let godFavorName = godfavor_for_beginner[index];
            //         let newPosition = playerController.godFavorAhchor.clone()
            //         newPosition.x += 1.3 * index * playerController.anchorSign
            //         const newGodFavor = new GodFavor(godFavorName, newPosition, playerType, this.experience.godFavorsInfo[`${godFavorName}`]);
            //         playerController.godFavors.push(newGodFavor);
            //         this.playerInteractableObjects.push(newGodFavor.mesh);
            //         this.gameObjects[newGodFavor.mesh.id] = newGodFavor;

            //     }




            players.forEach(playerType=>{
                let avatar = this.avatars[`${playerType}`]
                let stonePosInterval = {};
                stonePosInterval.x = 1.4;
                stonePosInterval.z = 1.5;
                let stoneAnchor = {}
                stoneAnchor.x = (1 + avatar.anchorSign) * stonePosInterval.x * -2 + avatar.healthStoneAnchor.x;
                stoneAnchor.y = 0.5;
                stoneAnchor.z = avatar.healthStoneAnchor.z

                console.log(avatar.eventEmitter)

                // console.log(stoneAnchor);
    
                for (let i = 0; i < 15; i++) {
                    let x = Math.floor(i % 5) * stonePosInterval.x + stoneAnchor.x;
                    let y = stoneAnchor.y
                    let z = (Math.floor(i / 5) - 1) * stonePosInterval.z + stoneAnchor.z;
    
                    // var stoneColor = {
                    //     top: 0x00e1ff,
                    //     bottom: 0x00ff11
                    // }
    
                    let position = new THREE.Vector3(x,y,z)
                    let healthStone = new HealthStone()
                    healthStone.SetPosition(position)
                    healthStone.model.mesh.castShadow = true

                    // let healthStone = new HealthStone(x, y, z, stoneColor[`${playerType}`], playerController);
                    avatar.healthStones.push(healthStone)



                    // this.gameObjects[`${healthStone.getID()}`] = healthStone;
                    this.playerInteractableObjects.push(healthStone.model.mesh);
                    avatar.healthStoneDictionary[`${healthStone.getID()}`] = {obj : healthStone, index : i};

                    if(i > 0)
                        avatar.healthStones[i - 1].next_stone = healthStone

                }
            })






            // this.gameObjects[`${nDice.dice.id}`] = nDice;
            
            // this.playerInteractableObjects.push(this.turnEndButton.mesh);




            // var stoneColor = {
            //     top : 0x00e1ff,
            //     bottom : 0x00ff11
            // }

            // this.turnEndButton = new TurnEndButton()
            // this.gameObjects[`${this.turnEndButton.mesh.id}`] = this.turnEndButton;
            // this.playerInteractableObjects.push(this.turnEndButton.mesh);



            // this.TurnEndButtonDBG = new TurnEndButtonDBG()
            // this.TurnEndButtonDBG.mesh.position.x += 4;
            // this.TurnEndButtonDBG.mesh.position.z -= 8;
            
            // this.gameObjects[`${this.TurnEndButtonDBG.mesh.id}`] = this.TurnEndButtonDBG;
            // this.playerInteractableObjects.push(this.TurnEndButtonDBG.mesh);




            // let playerTypes = ["top", "bottom"]
            // playerTypes.forEach(playerType => {
            //     let playerController = this.experience.game.playerController[`${playerType}`]

            //     let diceFaceInfo = [{
            //             "right" : {weapon : "axe", token : false},
            //             "left" : {weapon : "shield", token : false},
            //             "top" : {weapon : "axe", token : false},
            //             "bottom" : {weapon : "helmet", token : false},
            //             "front" : {weapon : "arrow", token : true},
            //             "back" : {weapon : "steal", token : true}},
                    
            //         {
            //             "right" : {weapon : "axe", token : false},
            //             "left" : {weapon : "shield", token : true},
            //             "top" : {weapon : "axe", token : false},
            //             "bottom" : {weapon : "steal", token : true},
            //             "front" : {weapon : "arrow", token : false},
            //             "back" : {weapon : "helmet", token : false}
            //         },
                    
            //         {
            //             "right" : {weapon : "axe", token : false},
            //             "left" : {weapon : "arrow", token : true},
            //             "top" : {weapon : "axe", token : false},
            //             "bottom" : {weapon : "helmet", token : true},
            //             "front" : {weapon : "steal", token : false},
            //             "back" : {weapon : "shield", token : false}
            //         },
                    
            //         {
            //             "right" : {weapon : "arrow", token : false},
            //             "left" : {weapon : "shield", token : false},
            //             "top" : {weapon : "axe", token : false},
            //             "bottom" : {weapon : "helmet", token : true},
            //             "front" : {weapon : "steal", token : true},
            //             "back" : {weapon : "axe", token : false}
            //         },
                    
            //         {
            //             "right" : {weapon : "axe", token : false},
            //             "left" : {weapon : "shield", token : true},
            //             "top" : {weapon : "axe", token : false},
            //             "bottom" : {weapon : "helmet", token : false},
            //             "front" : {weapon : "steal", token : false},
            //             "back" : {weapon : "arrow", token : true}

            //         },
                    
            //         {
            //             "right" : {weapon : "axe", token : false},
            //             "left" : {weapon : "shield", token : true},
            //             "top" : {weapon : "axe", token : false},
            //             "bottom" : {weapon : "arrow", token : false},
            //             "front" : {weapon : "steal", token : false},
            //             "back" : {weapon : "helmet", token : true}

            //         }
            //     ]

            //     for (let i = 0; i < 6; i++) {
            //         let nDice = new Dice(((i % 3) - 1) * (1.5), 5, sign[`${playerType}`] * ((10.5) + ((i % 2) * (1.5))), playerType, diceFaceInfo[i])
            //         this.gameObjects[`${nDice.dice.id}`] = nDice;
            //         playerController.dices.push(nDice);
            //         this.playerInteractableObjects.push(nDice.mesh);
            //     }



            //     const godFavorNames = ["Baldr", "Bragi", "Brunhild", "Freyja", "Freyr", "Frigg", "Heimdall", "Hel", "Idun", "Loki", "Mimir", "Odin", "Skadi", "Skuld", "Thor", "Thrymr", "Tyr", "Ullr", "Var", "Vidar"];

            //     // godFavorNames.forEach((godFavorName, index) => {
            //     //     const newGodFavor = new GodFavor(godFavorName, playerType);
            //     //     newGodFavor.mesh.position.x = sign[`${playerType}`] * (4 + (1.2 * (index % 7)));
            //     //     newGodFavor.mesh.position.z = sign[`${playerType}`] * (3.5 + (2 * Math.floor(index / 7)));
            //     //     this.experience.game.playerController[`${playerType}`].godFavors.push(newGodFavor);
            //     //     this.playerInteractableObjects.push(newGodFavor.mesh);
            //     //     this.gameObjects[newGodFavor.mesh.id] = newGodFavor;
            //     // })

            //     const godfavor_for_beginner = ["Thor", "Idun", "Odin"]

            //     for (let index = 0; index < 3; index++) {
            //         let godFavorName = godfavor_for_beginner[index];
            //         let newPosition = playerController.godFavorAhchor.clone()
            //         newPosition.x += 1.3 * index * playerController.anchorSign
            //         const newGodFavor = new GodFavor(godFavorName, newPosition, playerType, this.experience.godFavorsInfo[`${godFavorName}`]);
            //         playerController.godFavors.push(newGodFavor);
            //         this.playerInteractableObjects.push(newGodFavor.mesh);
            //         this.gameObjects[newGodFavor.mesh.id] = newGodFavor;

            //     }



            //     let nTray = new Tray(playerType)
            //     nTray.mesh.position.z = sign[`${playerType}`] * 5.5;

            //     playerController.tray = nTray;



            //     let stonePosInterval = {};
            //     stonePosInterval.x = 1.4;
            //     stonePosInterval.z = 1.5;
            //     let stoneAnchor = {}
            //     stoneAnchor.x = (1 + playerController.anchorSign) * stonePosInterval.x * -2 + playerController.healthStoneAnchor.x;
            //     stoneAnchor.y = 0.5;
            //     stoneAnchor.z = playerController.healthStoneAnchor.z
            //     // console.log(stoneAnchor);

            //     for (let i = 0; i < 15; i++) {
            //         let x = Math.floor(i % 5) * stonePosInterval.x + stoneAnchor.x;
            //         let y = stoneAnchor.y
            //         let z = (Math.floor(i / 5) - 1) * stonePosInterval.z + stoneAnchor.z;

            //         var stoneColor = {
            //             top: 0x00e1ff,
            //             bottom: 0x00ff11
            //         }

            //         let healthStone = new HealthStone(x, y, z, stoneColor[`${playerType}`], playerController);
            //         this.playerInteractableObjects.push(healthStone.mesh);
            //         this.gameObjects[`${healthStone.mesh.id}`] = healthStone;

            //         playerController.healthStoneSite.push(healthStone);



            //     }

            //     // console.log(playerController.healthStoneSite);


            // })


            // // let stoneanchor = { x: -9.5, y: 3, z: 4 }
            // // for (let i = 0; i < 15; i++) {
            // //     let x = Math.floor(i % 5) * 1.4 + stoneanchor.x;
            // //     let y = stoneanchor.y
            // //     let z = Math.floor(i / 5) * 1.5 + stoneanchor.z;
            // //     let healthStone = new HealthStone(x, 0.5, z);
            // //     this.playerInteractableObjects.push(healthStone.mesh);
            // //     this.gameObjects[`${healthStone.mesh.id}`] = healthStone;
            // // }



            // this.svg = new GodPiece()

            // // this.godSymbol = new TokenEffect();
            // // this.godSymbol.mesh.position.x = 0;
            // // this.godSymbol.mesh.position.y = 1;
            // // this.godSymbol.mesh.position.z = 0;
            // // // this.godSymbol.mesh.rotation.x -= Math.PI / 2;
            // // // console.log(this.godSymbol);

            // // this.godSymbol = new TokenEffect();
            // // this.godSymbol.mesh.position.x = -2;
            // // this.godSymbol.mesh.position.y = 1;
            // // this.godSymbol.mesh.position.z = 0;
            // // // this.godSymbol.mesh.rotation.x -= Math.PI / 2;


            // // this.godSymbol = new TokenEffect();
            // // this.godSymbol.mesh.position.x = 2;
            // // this.godSymbol.mesh.position.y = 1;
            // // this.godSymbol.mesh.position.z = 0;
            // // // this.godSymbol.mesh.rotation.x -= Math.PI / 2;

            // // this.godSymbol = new Token();
            // // this.godSymbol.mesh.position.y = 0.5;
            // // this.godSymbol.mesh.position.z = 1.5;

            // this.experience.game.gameStart()

        })


    }


    // const godFavorNames = ["Baldr", "Bragi", "Brunhild", "Freyja", "Freyr", "Frigg", "Heimdall", "Hel", "Idun", "Loki", "Mimir", "Odin", "Skadi", "Skuld", "Thor", "Thrymr", "Tyr", "Ullr", "Var", "Vidar"];

    // const godfavor_for_beginner = ["Thor", "Skadi", "Odin"]

    AddThing(avatar, playerInformation, avatardir) {
        // console.log(avatar)
        // console.log(playerInformation)
        // console.log(this.godFavors)

        // console.log(playerInformation)

        let godfavors = playerInformation.godFavors
        avatar.godFavors = []
        for (let index = 0; index < 3; index++) {
            let godFavorName = godFavorNames[godfavors[index]];
            let newPosition = avatar.godFavorAnchor.clone()
            newPosition.x += 1.8 * index * avatar.anchorSign
            
            let godfavor = this.godFavors[`${avatardir}`][`${godFavorName}`]
            godfavor.setPosition(newPosition)

            // console.log(godfavor)
            // console.log(avatar.index)
            // console.log(godFavorName)


            avatar.godFavors.push(godfavor);
            // console.log(avatar.godFavorDictionary)

            // console.log(avatar.godFavorDictionary)
            // console.log(godfavor.getID())
            
            avatar.godFavorDictionary[`${godfavor.getID()}`].index = index;



            // let godFavorName = godFavorNames[godfavors[index]];
            // let newPosition = avatar.godFavorAnchor.clone()
            // newPosition.x += 1.3 * index * avatar.anchorSign
            // const godfavor = new GodFavor(godFavorName, newPosition, this.experience.godFavorsInfo[`${godFavorName}`], this.experience.godFavorsAction[`${godFavorName}`]);
            // avatar.godFavors = []
            // avatar.godFavors.push(godfavor);

            // avatar.godFavorDictionary = {}
            // this.playerInteractableObjects.push(godfavor.mesh);
            // this.gameObjects[godfavor.mesh.id] = godfavor;

        }

    }


    CardBanMove(avatar_dir, card_index){
        let godFavorName = godFavorNames[card_index]
        let godFavor = this.godFavors["bottom"][`${godFavorName}`]

        godFavor.state = "banned_sign"
        godFavor.Ban_On()

        // if(avatar_dir != "bottom"){
        // godFavor.Ban_On()
        // }
            
        return this.stamp.Stamp(godFavor.getPosition().clone())
    }

    /*
        user : < "bottom" or "top" >
    */
    CardPickMove(avatar_dir, card_index, acc_cnt){
        let card_width = 1.7
        let card_height = 2.2
        let bias = 0

        let godFavorName = godFavorNames[card_index]
        let godFavor = this.godFavors["bottom"][`${godFavorName}`]

        godFavor.state = "waiting"

        let anim = godFavor.Blink()
        // let anim = gsap.timeline()
        // if(avatar_dir != "bottom"){
        //     anim = godFavor.Blink()
        // }

        let anchor

        if (avatar_dir == "bottom")
            anchor = new THREE.Vector3(card_width * 2, 0, card_height * 3 + bias)
        else
            anchor = new THREE.Vector3(card_width * -3, 0, card_height * -2.5 + bias)

        anchor.x += acc_cnt * card_width * 1.25
        anchor.y = 1.5

        return new Promise((res)=>{
            anim.then(()=>{
                godFavor.Highlight_On()
                gsap.to(godFavor.mesh.position, {duration : 0.3, y : 1.5, ease : "Power2.easeOut"})
                godFavor.moveTo(anchor, 0.3).then(()=>{res(1)})
            })
        })

        
        // anim.then(()=>{console.log("hello world")})
        
    }



    ArrangeCards(game_mode){
        
        let ready_position = new THREE.Vector3(0, 1.5, -11)
        // console.log(this.experience.controller.avatars.bottom)

        let card_width = 1.875
        let card_height = 2.75

        let setup_anchor
        let height_cnt, width_cnt

        let bias = 0.25

        if(game_mode == "liberty"){
            height_cnt = 4
            setup_anchor = new THREE.Vector3(
                // -4 * card_width, 0.5, -5 * card_height
                -card_width * 5, 0.5, (bias - (height_cnt - 1) / 2) * card_height
            )
        }
        else {
            // game_mode == "draft"
            card_width = 2.2
            height_cnt = 3
            setup_anchor = new THREE.Vector3(
                // -4 * card_width, 0.5, -5 * card_height
                -card_width * 3, 0.5, (bias - (height_cnt - 1) / 2) * card_height
            )
        }
        //(0.5 - (height_cnt - 1) / 2)
        width_cnt = godFavorNames.length / height_cnt
        width_cnt = parseInt(Math.ceil(width_cnt))

        let proms = []


        // let cardID = this.godFavors["bottom"][`${godFavorName}`]
        let avatar = this.avatars.bottom
        let cardID

        godFavorNames.forEach((godFavorName, card_index) =>{
            // console.log(this.godFavors["bottom"])
            // console.log(godFavorName)

            // console.log(this.godFavors["bottom"])
            // console.log(avatar.godFavorDictionary)

            cardID = this.godFavors["bottom"][`${godFavorName}`].getID()
            // console.log(cardID)
            avatar.godFavorDictionary[`${cardID}`].index = card_index


            let godFavor = this.godFavors["bottom"][`${godFavorName}`]
            // console.log(godFavor)
            godFavor.index = card_index;
            godFavor.setPosition(ready_position)
            
            let x = setup_anchor.x + card_width * (card_index % width_cnt)
            let y = setup_anchor.y
            let z = setup_anchor.z + card_height * (Math.floor(card_index / width_cnt))

            proms.push(godFavor.moveTo(new THREE.Vector3(x,y,z), card_index / 10))
        })

        


        return Promise.all(proms)
    }

    OrganizeCards(){
        this.stamp.ClearBanSign()

        let ready_position = new THREE.Vector3(0, 0.5, -12)
        let proms = []


        godFavorNames.forEach((godFavorName, card_index) =>{
            let godFavor = this.godFavors["bottom"][`${godFavorName}`]
            godFavor.Highlight_Off()
            godFavor.Ban_Off()
            
            proms.push(godFavor.moveTo(ready_position, card_index / 30))
        })
        
        return Promise.all(proms)
    }


    CreateDice(index){
        let newDice = new Dice(diceFaceInfo[index])

        
        // let dice = new Dice(faceInfo)
        this.dices.push(newDice)
        this.gameObjects[`${newDice.getID()}`] = newDice;
        this.playerInteractableObjects.push(newDice.mesh.mesh);


        // this.scene.add(newDice)
        return newDice
    }

    RemoveDice(dice){
        this.dices.pop()
        delete this.gameObjects[`${dice.getID()}`]
        this.playerInteractableObjects.pop()
        
    }


    TurnOnInteract(objs){
        // this.gameObjects[`${healthStone.getID()}`] = healthStone;
        objs.forEach(obj=>{
            this.gameObjects[`${obj.getID()}`] = obj
        })
    }


    TurnOffInteract(objs){
        objs.forEach(obj=>{
            delete this.gameObjects[`${obj.getID()}`]
        })
    }


    update(deltaTime) {
        // if (this.fox)
        //     this.fox.update()

        // this.dices.forEach(dice=>{
        //     dice.update()
        // })

        this.avatars.top.dices.forEach(dice=>{
            dice.update(deltaTime)
        })

        this.avatars.bottom.dices.forEach(dice=>{
            dice.update(deltaTime)
        })

        // this.coinMesh.rotation.x += 0.01;
        // this.coinMesh.rotation.y += 0.002;

        // if(this.physics)
        //     this.physics.update()




        // let uTime = Math.sin(this.experience.time.elapsed * 0.001) * 0.5 + 0.5;
        
        uTime += deltaTime / 1000.0;
        energy_material.uTime.value = uTime


        // mask_material.uTime.value = uTime
        // outline_material.uTime.value = uTime

        // let uTime_ = Math.sin(this.experience.time.elapsed * 0.001) * 0.5 + 0.5;


        // this.particle.material.uTime.value = uTime_;
    }
}

let uTime=0

const godFavorNames = ["Baldr", "Bragi", "Brunhild", "Freyja", "Freyr", "Frigg", "Heimdall", "Hel", "Idun", "Loki", "Mimir", "Odin", "Skadi", "Skuld", "Thor", "Thrymr", "Tyr", "Ullr", "Var", "Vidar"];