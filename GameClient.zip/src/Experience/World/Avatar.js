import * as THREE from 'three'
import Experience from '../Experience.js'
import Token from './Token.js'

export default class Avatar{
    constructor(anchorSign) {

        this.experience = new Experience()
        this.scene = this.experience.scene
        this.debug = this.experience.debug

        // data
        this.dices = [];
        this.diceDictionary = {};
        this.godFavors = [];
        this.godFavorDictionary = {};
        this.healthStones = [];
        this.healthStoneDictionary = {}
        this.health = 15
        this.health_anim_index
        this.tokens = [];

        this.tray = new THREE.Vector3();

        this.bowl


        // 주사위 대기열
        this.chosenDicesSite = []
        this.waitingDicesSite = [];
        this.actionEndDicesSite = [];
        this.diceChosenIndex = []; // this.diceWaitingIndex[i] : i 주사위의 chosenDicesSite 내의 index
       

        this.sortedDiceForBattle = []

        // anchors
        this.diceStartAnchor = new THREE.Vector3(0, 5, 11.5 * anchorSign)
        this.diceChosenAnchor = new THREE.Vector3(4, 0.5, 1.8 * anchorSign);
        this.diceWaitingAnchor = new THREE.Vector3(-9, 0.5, 1.8 * anchorSign);
        this.actionEndAnchor = new THREE.Vector3(4 * anchorSign, 0.5, 8.75 * anchorSign);
        this.tokenStackAnchor = new THREE.Vector3(4 * anchorSign, 0, 4 * anchorSign)
        this.godFavorAnchor = new THREE.Vector3(4.5 * anchorSign, 0.5, 7 * anchorSign)
        this.healthStoneAnchor = new THREE.Vector3(-3.9 * anchorSign, 0.5, 6 * anchorSign)
        this.anchorSign = anchorSign


        this.eventEmitter
        this.index
        
        // this.setDebug()

        // this.PrintAnchors()

    }


    InitialGame(info){
        this.ResetRound()

        this.tokens.forEach(token=>{
            token.destroy()
        })
        this.tokens = []

        this.healthStones.forEach(healthStone=>{
            let position = healthStone.GetPosition().clone()
            position.y = this.healthStoneAnchor.y
            // healthStone.MoveTo(position)
            healthStone.SetPosition(position)
            healthStone.eventEmitter = this.eventEmitter;
            healthStone.avatarIndex = this.index;
        })
        this.health = 15
        this.health_anim_index = 15

        let damageHealth = this.health - info.health
        // this.health = info.health
        for (let i = 0; i < damageHealth; i++)
            this.GetTargetHealthStone(null)


        let addedToken = info.token
        for (let i = 0; i < addedToken; i++)
            this.CreateNewToken(this.GetNextTokenPosition())    
            
            
        this.godFavors.length = 0

        // this.health = info.health

    }


    OrganizeTable(){
        // console.log(this.tray)
        let pos = this.tray.clone()
        pos.z +=  6.5 * this.anchorSign

        this.bowl.Move(pos)

        this.healthStones.forEach(stone=>{
            stone.mesh.position.y = -5
        })
    }



    SetupTable(){
        let pos = this.tray.clone()

        this.bowl.Move(pos)

        this.healthStones.forEach(stone=>{
            stone.mesh.position.y = this.healthStoneAnchor.y
        })

    }


    GetDicesIndexsOnCondition(condition){
        let indexes = []
        this.dices.forEach((dice,index)=>{
            if(condition(dice) && dice.state != "ban")
                indexes.push(index)
        })
        return indexes
    }



    GetDiceMarks(){
        let marks = []
        this.sortedDiceForBattle.forEach(dice=>{
            if(dice.state !== "ban")
                marks.push(...dice.getMarks())
        })

        return marks;
    }


    GetSortedDiceForBattle(){
        return this.sortedDiceForBattle;
    }


    ResetRound(){
        this.chosenDicesSite = []
        this.waitingDicesSite = []
        this.actionEndDicesSite = []
        this.diceChosenIndex = []

        this.dices.forEach(dice=>{
            dice.ResetRound()
        })
    }

    DiceToActionEnd(dice, index){

        let pos = this.actionEndAnchor.clone()
        pos.x += index * this.anchorSign * 1.3
        let ret = dice.DiceToActionEnd(pos)
        return ret
        // promises.push(ret)
    }

    DicesToWaiting(chosenDicesIndex){
        // console.log(chosenDicesIndex);
        // DiceToWaiting(pos)

        // if(this.diceChosenIndex.includes(index))
        // chosenDice들을 x 좌표 기준으로 정렬한다
        let tmpDices = []
        chosenDicesIndex.forEach(chosenIndex=>{
            tmpDices.push({index : chosenIndex, x : this.dices[chosenIndex].getPosition().x})
        })
        tmpDices.sort((a,b)=>{return a.x - b.x})
        tmpDices.forEach((element,i)=>{
            chosenDicesIndex[i] = element.index
        })
        
        let nPosition = new THREE.Vector3
        nPosition.copy(this.diceWaitingAnchor);
        nPosition.x += this.waitingDicesSite.length * 1.3

        let promises = []
        chosenDicesIndex.forEach(index => {
            let ret = this.dices[index].DiceToWaiting(nPosition)
            promises.push(ret)
            this.waitingDicesSite.push(this.dices[index])        
            nPosition.x +=  1.3
        })

        this.chosenDicesSite = []
        return promises
    }


    Withdraw(){
        this.dices.forEach(dice=>{
            dice.Withdraw(this.diceStartAnchor)
        })
    }


    // diceFaces = [...INT]     (0~5 or -1 = 안굴림)
    RollDices(diceDirs, diceTransformLogs){
        // this.RetrieveDices()


        // let diceInfos = this.CalcRolledDiceTransform(diceDirs)
        // console.log(diceInfos)
        let logIndex = 0;
        let promises = []
        this.dices.forEach((dice, index) =>{
            if(diceDirs[index] != null){
                let ret = this.dices[index].Roll(diceDirs[index], diceTransformLogs[logIndex], this.diceStartAnchor)
                promises.push(ret)
                logIndex++;
            }
                // this.dices[index].Roll(diceInfo.position, diceInfo.face, diceInfo.rotation, this.diceStartAnchor);
        })
        // promises.then((resolve)=>{console.log(resolve)})
        // Promise.all(promises).then((resolve)=>{console.log(resolve)})
        return promises
    }


    PhysicsRollDices(){
        this.dices.forEach(dice=>{
            dice.PhysicsRoll();
        })
    }

    /*
    CalcRolledDiceTransform(diceFaces){
        let totalAngle = Math.random() * 2 * Math.PI;

        let diceInfos = [];
        diceInfos[0] = {}
        diceInfos[0].angle = 0.0;
        diceInfos[0].radius = Math.random() * 0.3;
        diceInfos[0].face = diceFaces[0]

        for (let i = 1; i < diceFaces.length; i++) {
            let diceInfo = {}
            diceInfo.angle = (2 * Math.PI * (i - Math.random() * 0.35)) / (5.0)
            diceInfo.radius = 1.4 + 0.5 * Math.random();
            diceInfo.face = diceFaces[i];
            diceInfos.push(diceInfo)
        }


        let ret = []
        diceInfos.forEach((diceInfo, index)=>{
            let position = new THREE.Vector3(
                diceInfo.radius * Math.cos(totalAngle + diceInfo.angle) + this.tray.x,
                0.5,
                diceInfo.radius * Math.sin(totalAngle + diceInfo.angle) + this.tray.z
            )
            
            let face = diceInfo.face;
            let rotation = Math.PI * 2 * Math.random();

            ret[index] = {}
            ret[index].position = position;
            ret[index].face = face;
            ret[index].rotation = rotation;

            // this.dices[index].roll(position, face, rotation)
        })

        return ret
    }
    */

    // return = {type : "dice", index : 0}
    checkSelectedObject(obj){
        if(obj.getID() in this.diceDictionary){
            // console.log(this.diceDictionary[obj.getID()])
            return {type : "dice", index : this.diceDictionary[obj.getID()].index}
        }

        if(obj.getID() in this.godFavorDictionary){
            return {type : "godfavor", index : this.godFavorDictionary[obj.getID()].index}
        }

        
        if(obj.getID() in this.healthStoneDictionary){
            return {type : "healthstone", index : this.healthStoneDictionary[obj.getID()].index}
        }
        
    }

    FindFromDictionary(obj_id){
        if(obj_id in this.diceDictionary){
            // console.log(this.diceDictionary[obj.getID()])
            return this.diceDictionary[obj_id].obj
        }

        if(obj_id in this.godFavorDictionary){
            return this.godFavorDictionary[obj_id].obj
        }

        
        if(obj_id in this.healthStoneDictionary){
            return this.healthStoneDictionary[obj_id].obj
        }

        return null
    }

    SetDiceFormation(diceFormation){
        this.sortedDiceForBattle = []

        // this.waitingDicesSite 의 주사우들을 선형탐색하여 diceFormation 정보에 맞게끔 정렬시킨다.
        // console.log(diceFormation)


        let weaponsOnSector = diceFormation.weapons
        let actionPosition = this.diceWaitingAnchor.clone()
        actionPosition.x = this.diceWaitingAnchor.x + 1
        let moveOrder = 0
        let baseLine = actionPosition.x;
        let promises = []
        for(let sectorIndex = 0; sectorIndex < 6; sectorIndex++){
            let weaponOnSector = weaponsOnSector[sectorIndex]

            this.dices.forEach((dice, index)=>{
                // console.log(dice.state)
                if(dice.state !== "ban" && dice.getWeapon() == weaponOnSector){
                    // console.log(`${index}-th dice is formationed`)
                    this.sortedDiceForBattle.push(dice)
                    let ret = dice.MoveToAction(actionPosition.clone(), moveOrder)
                    promises.push(ret)
                    actionPosition.x += 1.3
                    moveOrder++
                    dice.state = "waiting"
                }
            })
            // actionPosition.x += 0.5
            baseLine += (1.3 * diceFormation[`${sectorIndex}`] + 0.5)
            actionPosition.x = baseLine
        }

        // console.log(this.sortedDiceForBattle)

        
        return promises
    }


    // 대기열을 확인하여 적절한 장소로 fly 시킨다.
    // 이전에 작성했던 코드들을 참고할것
    ChooseDice(diceIndex, phase){
        let emptyIndex;
        for (emptyIndex = 0; emptyIndex < 6; emptyIndex++)
            if (this.chosenDicesSite[emptyIndex] == null)
                break;

        let nPosition = new THREE.Vector3

        switch(phase){
            case "roll":
                nPosition.copy(this.diceChosenAnchor);
                nPosition.x += (emptyIndex * 1.3);
        
                this.chosenDicesSite[emptyIndex] = this.dices[diceIndex]
                this.diceChosenIndex[diceIndex] = emptyIndex;

                break;

            case "resolution":
                nPosition.copy(this.dices[diceIndex].getPosition())
                nPosition.y += 3

                break;
        }



        
        let prom = this.dices[diceIndex].ChooseDice(nPosition, phase)

        return prom
    }


    CancleDice(diceIndex, phase){
        let prom = this.dices[diceIndex].CancleDice(phase)
        this.chosenDicesSite[this.diceChosenIndex[diceIndex]] = null
        this.diceChosenIndex[diceIndex] = -1

        return prom
    }


    ClickDice(diceIndex, phase){
        let diceState = this.dices[diceIndex].GetDiceState()
        if(diceState === "tray" || diceState === "waiting"){
            return this.ChooseDice(diceIndex, phase)
        }
        else if(diceState === "chosen" || diceState === "levitation"){
            return this.CancleDice(diceIndex, phase)
        }
    }


    GetDiceState(index){
        return this.dices[index].GetDiceState()
    }

    GodFavorPower(index, level){
        

        // 사용 가능 여부 확인
        // 상대의 방해때문에 사용 못할 수 있음
        
        // 일단은 코스트 지불 없이 사용
        this.godFavors[index].Power(level)

    }

    AddOtherToken(newToken){
        this.tokens.push(newToken)
    }


    Check_Token_FreeSpace(){
        return this.tokens.length < 50
    }

    GetToken(dicesWithTokenIndex){
        let promises = []
        dicesWithTokenIndex.forEach(index=>{
            let dicePosition = this.dices[index].getPosition()
            
            let prom = this.CreateNewToken(dicePosition)
            promises.push(prom)
        })
        return promises
    }

    SpendToken(cnt){
        let promises = []
        this.eventEmitter.trigger(`${this.index}-use-token`, [cnt])
        for(let i=0; i<cnt; i++){
            if(this.tokens.length == 0)
                return;

            promises.push(this.tokens.pop().Spend())
        }

        return Promise.all(promises)
    }

    CreateNewToken(from){
        if(this.tokens.length >= 50)
            return null
        
        let token = new Token(from)
        let to = this.GetNextTokenPosition()
        let prom = token.initialMove(to)
        this.tokens.push(token)

        return prom
    }

    GetNextTokenPosition() {
        let newTokenSite = new THREE.Vector3(0, 0, 0)
        let cnt = this.tokens.length

        let unit_length = 1.3

        let origin = this.tokenStackAnchor.clone()
        if(this.anchorSign < 0){
            origin.z += this.anchorSign * unit_length * 0.5
            origin.x += this.anchorSign * unit_length * 4
        }

        newTokenSite.z = (unit_length * Math.floor(cnt / 25)) + origin.z

        cnt = Math.floor(cnt % 25)
        newTokenSite.x = unit_length * Math.floor(cnt / 5) + origin.x

        newTokenSite.y = 0.2 + 0.25 * Math.floor(cnt % 5) + origin.y

        // newTokenSite.x *= this.anchorSign;
        // newTokenSite.z *= this.anchorSign;

        return newTokenSite;
    }

    GetHealth(){
        return this.health;
    }


    GetLastHealthStone(){
        if (this.health > 0)
            return this.healthStones[this.health - 1]
        else
            return null;
    }

    GetTargetHealthStone(weaponType = null, needAnimSync = false) {
        let ret = null
        if (this.health > 0) {
            let healthStonePosition = this.healthStones[--this.health].GetPosition().clone()
            this.health_anim_index--;

            // console.log(this.eventEmitter)

            // if(weaponType != null)
            this.eventEmitter.trigger(`${this.index}-damage-${weaponType}`, [healthStonePosition])
            // this.eventEmitter.trigger(`${this.avatarIndex}-damage-${weapon_kind}-anim`,[this.GetPosition()]);
            // console.log(`${this.index}-damage-${weaponType}`)
            if (!needAnimSync){
                // this.healthStones[this.health].mesh.position.y -= 5
                this.healthStones[this.health].Damaged()
            }
            ret = healthStonePosition
        }

        if (this.health <= 0) {
            this.experience.controller.FinishGame(this.index)
        }

        return ret;
    }



    ConvertDiceMark(weaponName, color, dicesIndex, changedValue, transforms){
        let promises = [], callbacks = []

        dicesIndex.forEach((index, i)=>{
            let dice = this.dices[index]
            let value = changedValue[i]
            let ret = dice.ConvertDiceMark(value, weaponName, color, transforms)
            promises.push(ret[0])
            callbacks.push(ret[1])
        })

        // this.dices.forEach(dice=>{
        //     if(condition(dice)){
        //         let ret = dice.ConvertDiceMark(cnt, weaponName, color, transforms)
        //         promises.push(ret[0])
        //         callbacks.push(ret[1])
        //     }
        // })
        return [promises, callbacks]
    }


    HealthStonesInteractOn(){
        this.experience.world.TurnOnInteract(this.healthStones)
    }


    HealthStonesInteractOff(){
        this.experience.world.TurnOffInteract(this.healthStones)
    }


    Heal(){
        // let promise
        if (this.health < 15) {
            // this.healthStones[this.health].mesh.position.y = this.healthStoneAnchor.y
            // console.log(this.healthStones[this.health])
            // this.healthStones[this.health].Recovery()
            // promise = this.healthStones[this.health].Blink()
            
            this.health++
        }
    }


    HealAnimation(animation_type = null){
        let promise
        if(this.health_anim_index < 15){
            this.healthStones[this.health_anim_index].Recovery(animation_type)
            promise = this.healthStones[this.health_anim_index].Blink()
            this.health_anim_index++;
        }
        return promise
    }


    BanDices(bannedDicesIndex){
        // this.dices.forEach(dice=>{
        //     if(dice.state === "levitation"){
        //         this.DiceToActionEnd(dice, 6)
        //         dice.state = "ban"
        //     }
        // })
        let promises = []
        bannedDicesIndex.forEach(index=>{
            let prom = this.DiceToActionEnd(this.dices[index], 9)
            promises.push(prom)
            this.dices[index].state = "ban"
        })
        return Promise.all(promises)
    }


    GetTargetToken(){
        // console.log(this.tokens)
        if(this.tokens.length > 0)
            return this.tokens.pop()
        else
            return null
    }


    AddDices(nDices){
        this.dices.push(...nDices)

        nDices.forEach((nDice, index)=>{
            //0xbf009c #ff80e8

            this.diceDictionary[`${nDice.getID()}`] = {obj : nDice, index : 6 + index}

            nDice.setDiceMaterialColor(new THREE.Color(0xff80e8))
            
            nDice.DiceToActionEnd = function(){
                this.Disappear()
                return null
            }
        })
        // console.log(this.dices)
    }


    ReduceDices(cnt){
        for(let i=0; i<cnt; i++){
            let deletedDice = this.dices.pop()
            let diceID = deletedDice.getID()
            delete this.diceDictionary[`${diceID}`]
            this.experience.world.RemoveDice(deletedDice)
        }
    }

    GetAvatarInfo(){
        let dicesState = []
        this.dices.forEach(dice=>{
            dicesState.push(dice.GetDiceState())
        })
        return {
            health : this.health,
            token : this.tokens.length,
            dicesState : dicesState
        }
    }


    ForceSync(info) {
        // info = {hp, token, dices = [{dir, state}, ...], godFavors}
        let hp_diff = info.health - this.GetHealth()

        if (hp_diff > 0) {
            for (let i = 0; i < hp_diff; i++) {
                this.Heal()
                this.HealAnimation()
            }
        }
        else if (hp_diff < 0) {
            hp_diff *= -1
            for (let i = 0; i < hp_diff; i++) {
                this.GetTargetHealthStone("none")
            }
        }

        let token_diff = info.token - this.tokens.length
        // console.log(token_diff)

        if (token_diff > 0) {
            for (let i = 0; i < token_diff; i++)
                this.CreateNewToken(this.GetNextTokenPosition())

        }
        else if (token_diff < 0) {
            this.SpendToken(token_diff * -1)
        }




        // console.log(info)

    }



    _DBG_SetDiceFaceColor(index){
        this.dices[index]._DBG_setFaceColor()

    }
    _DBG_ResetDiceFaceColor(index){
        this.dices[index]._DBG_resetFaceColor()
    }

    SetDiceMaterialColor(index, hsl){
        let color = new THREE.Color()
        color.setHSL(hsl[0], hsl[1], hsl[2])
        this.dices[index].setDiceMaterialColor(color)

    }

    ResetDiceMaterialColor(index){
        this.dices[index].resetDiceMaterialColor()
    }


    setDebug() {}


    PrintAnchors(){
        // this.diceStartAnchor = new THREE.Vector3(0, 5, 11.5 * anchorSign)
        // this.diceChosenAnchor = new THREE.Vector3(4, 0.5, 1.3 * anchorSign);
        // this.diceWaitingAnchor = new THREE.Vector3(-9, 0.5, 1.3 * anchorSign);
        // this.actionEndAnchor = new THREE.Vector3(4 * anchorSign, 0.5, 8 * anchorSign);
        // this.tokenStackAnchor = new THREE.Vector3(4, 0, 3.5 * anchorSign)
        // this.godFavorAnchor = new THREE.Vector3(4 * anchorSign, 0.5, 6 * anchorSign)
        // this.healthStoneAnchor = new THREE.Vector3(-3.9 * anchorSign, 0.5, 6 * anchorSign)
    
        let anchors = [this.diceStartAnchor, this.diceChosenAnchor, this.diceWaitingAnchor, this.actionEndAnchor, this.tokenStackAnchor, this.godFavorAnchor, this.healthStoneAnchor ]

        let anchor_geo = new THREE.BoxGeometry(1,1,1)
        anchors.forEach((anchor, index)=>{
            let anchor_mat = new THREE.MeshBasicMaterial({transparent : true, opacity : 0.5})
            anchor_mat.color.setHSL(index / anchors.length, 1, 0.5)
            console.log(index / anchors.length)

            let anchor_mesh = new THREE.Mesh(anchor_geo, anchor_mat)
            anchor_mesh.position.copy(anchor)
            this.scene.add(anchor_mesh)
        })
    
    
    }

}