import * as THREE from 'three'
import Experience from '../Experience.js'
import gsap from 'gsap';

export default class FlipCoin {
    constructor() {
        this.experience = new Experience()
        this.scene = this.experience.scene

        let coinGeo = new THREE.CylinderGeometry( 1, 1, 0.15, 32 );
        let coinMat = [
            new THREE.MeshStandardMaterial({color : "gold", metalness : 0.95, roughness: 0.05}),
            new THREE.MeshStandardMaterial({color : "gold", metalness : 0.95, roughness: 0.05}),
            new THREE.MeshStandardMaterial({color : "silver", metalness : 0.95, roughness: 0.05})
        ]
        this.coinMesh = new THREE.Mesh(coinGeo, coinMat)
        this.scene.add(this.coinMesh)

    }


    Flip(firstPlayer, delay_){
        this.coinMesh.position.y = 0.15 / 2
        this.coinMesh.rotation.x = firstPlayer * Math.PI

        let anim = gsap.timeline()
            .from(this.coinMesh.position,
                { delay: delay_, duration: 0.7, ease: "Power1.easeIn", y: 7 })
            .from(this.coinMesh.position,
                { duration: 0.7, ease: "Power2.easeOut", z: 11.5 }, "<")
            .from(this.coinMesh.rotation,
                { duration: 0.7, ease : "none", x : Math.PI * 6}, "<")

        gsap.to(this.coinMesh.position, {duration: 1, delay : 3.7 + delay_, y : -1})

        return anim

    }
}