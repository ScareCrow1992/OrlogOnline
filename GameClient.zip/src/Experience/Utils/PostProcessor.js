import * as THREE from 'three'
import Experience from '../Experience.js'
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutlinePass } from 'three/addons/postprocessing/OutlinePass.js';
import { FXAAShader } from 'three/addons/shaders/FXAAShader.js';
import { GammaCorrectionShader } from 'three/addons/shaders/GammaCorrectionShader.js'
import UnrealBloomComposer from './UnrealBloomComposer.js'

// import { nodeFrame } from 'three/examples/jsm/renderers/webgl/nodes/WebGLNodes.js';

export default class PostProcessor
{
    constructor(renderer)
    {
        this.experience = new Experience()
        this.sizes = this.experience.sizes
        this.renderer = renderer;
        this.composer = new EffectComposer(renderer);
        this.composer.renderToScreen=false;
        
        // this.composer.physicallyCorrectLights = true
        // this.composer.outputEncoding = THREE.sRGBEncoding
        // this.composer.toneMapping = THREE.CineonToneMapping
        // this.composer.toneMappingExposure = 1.75
        // this.composer.shadowMap.enabled = true
        // this.composer.shadowMap.type = THREE.PCFSoftShadowMap
        // this.composer.setClearColor('#211d20')

        this.composer.setSize(this.sizes.width, this.sizes.height)
        this.composer.setPixelRatio(Math.min(this.sizes.pixelRatio, 2))


        this.gammaComposer = new EffectComposer(renderer);
        this.gammaComposer.setSize(this.sizes.width, this.sizes.height)
        this.gammaComposer.setPixelRatio(Math.min(this.sizes.pixelRatio, 2))

        this.selectedObjects = [];

        this.passes = {};

        // composer = new EffectComposer( renderer );

        this.setInstance()
    }

    setInstance(){
        this.passes.renderPass = new RenderPass( this.experience.scene, this.experience.camera.instance );
		this.composer.addPass( this.passes.renderPass );

        
        this.passes.gammaPass = new ShaderPass(GammaCorrectionShader)
        this.composer.addPass(this.passes.gammaPass)

        // this.finalGammaComposer = new EffectComposer(this.renderer)
        // this.finalGammaComposer.renderToScreen = false;
        // this.finalGammaComposer.readBuffer = this.unrealBloomComposer.finalComposer.renderTarget2;
        // this.passes.gammaCorrectionPass = new ShaderPass(GammaCorrectionShader)
        // this.finalGammaComposer.addPass(this.passes.gammaCorrectionPass)
     

        
        this.passes.effectFXAA = new ShaderPass( FXAAShader );
        this.pixelRatio = this.renderer.getPixelRatio();
        this.passes.effectFXAA.material.uniforms[ 'resolution' ].value.set( 1 / (window.innerWidth * this.pixelRatio), 1 / (window.innerHeight * this.pixelRatio) );
        this.composer.addPass( this.passes.effectFXAA );

        
        this.unrealBloomComposer = new UnrealBloomComposer(this.composer.renderTarget2)


        
        
        this.passes.outlinePass = new OutlinePass( new THREE.Vector2( window.innerWidth, window.innerHeight ), this.experience.scene, this.experience.camera.instance );
        // this.passes.outlinePass.selectedObjects = this.experience.mouseManager.selectedObject;

        this.passes.outlinePass.edgeStrength = 21.0;
        this.passes.outlinePass.edgeGlow = 0.8;
        this.passes.outlinePass.edgeThickness = 7;
        this.passes.outlinePass.pulsePeriod = 0.0;
        this.passes.outlinePass.visibleEdgeColor.set('#ffC800');
        this.passes.outlinePass.hiddenEdgeColor.set('#ffC800');
        this.composer.addPass( this.passes.outlinePass );


    }

    resize()
    {
        this.composer.setSize(this.sizes.width, this.sizes.height)
        this.composer.setPixelRatio(Math.min(this.sizes.pixelRatio, 2))
        
        this.pixelRatio = this.renderer.getPixelRatio();
        this.passes.effectFXAA.material.uniforms[ 'resolution' ].value.set( 1 / (window.innerWidth * this.pixelRatio), 1 / (window.innerHeight * this.pixelRatio) );
    }

    update()
    {
        this.composer.render();
        this.unrealBloomComposer.render();
        // this.finalGammaComposer.render();

    }

    hover_on(obj){
        this.passes.outlinePass.selectedObjects = obj;
        // console.log("hover_on");
    }

    hover_off(){
        this.passes.outlinePass.selectedObjects = [];
    }

}