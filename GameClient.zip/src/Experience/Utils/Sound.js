import * as THREE from 'three'
import Experience from '../Experience.js'
import EventEmitter from './EventEmitter.js'

export default class Sound extends EventEmitter {
    constructor() {
        super()

        this.experience = new Experience()
        this.resources = this.experience.resources
        this.camera = this.experience.camera.instance


        const listener = new THREE.AudioListener();
        this.camera.add(listener);

        // create a global audio source
        const bgm = new THREE.Audio(listener);

        // listener.context.resume().then(()=>{console.log("hello")})
        // sound.context.resume().then(()=>{console.log("world")})

        this.isOn = false

        this.dice_rolling = new THREE.Audio(listener);


        this.resources.on('ready', () => {

            window.addEventListener("mouseup", ()=>{
                if(this.isOn == false){
                    this.isOn = true;
                    bgm.setBuffer(this.resources.items.bgm);
                    bgm.setLoop(true);
                    bgm.setVolume(0.5);

                    bgm.play();
                    bgm.autoplay = true;


                    
                    this.dice_rolling.setBuffer(this.resources.items["dice-rolling"])
                    this.dice_rolling.setLoop(false);
                    this.dice_rolling.setVolume(1.0);
                    // this.dice_rolling.play();

                }
            })

            // sound.resume()

        })
    }

    DiceRolling(){
        this.dice_rolling.play(0.8)
    }

}