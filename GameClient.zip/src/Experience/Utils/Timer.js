import * as THREE from 'three'
import Experience from '../Experience.js'


// Time 인스턴스에 의해서만 조작됨
export default class Timer  {
    constructor(emitter) {

        this.experience = new Experience()
        this.resources = this.experience.resources
        this.camera = this.experience.camera.instance
        this.emitter = emitter

        this.time = -1;
        this.dom = document.getElementById("timer-viewer")
        this.domTxt = document.getElementById("timer")
        this.state = true;

        window.addEventListener("keydown", (e)=>{
            // domTxt.innerHTML = e.key
            switch (e.key) {
                case "u":
                    this.dom.classList.add("visible")
                    break;

                case "i":
                    this.dom.classList.remove("visible")
                    break;


            }
        })
    }


    SetTimer(value, isStart = true) {
        this.time = value
        this.domTxt.innerHTML = Math.ceil(this.time / 1000)

        if (isStart)
            this.StartTimer()

    }


    StartTimer(){
        this.state = true
        this.dom.classList.add("visible")
    }

    StopTimer(){
        this.state = false;
        this.dom.classList.remove("visible")
    }

    update(delta){
        if(this.state){
            this.domTxt.innerHTML = Math.ceil(this.time / 1000)
            this.time -= delta

            
            if(this.time <= 0){
                this.emitter.trigger("timeover")
                this.StopTimer()
            }
        }
    }


}