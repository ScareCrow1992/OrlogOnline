import * as THREE from 'three'
import Experience from '../Experience.js'
import EventEmitter from './EventEmitter.js'
import DisappearMaterial from '../Shaders/Materials/DisappearMaterial.js'

export default class Material extends EventEmitter {
    constructor(playertype) {
        super()

        // {top, bottom}
        this.playerType = playertype;

        this.experience = new Experience()
        this.resources = this.experience.resources
        this.scene = this.experience.scene
        this.debug = this.experience.debug

        this.materialColor = {
            value : "#feb2b2"
        }
        
        // this.setDebug()


        // ,
        // envMap : this.experience.world.environment.environmentMap

        this.resources.on('ready', () => {


            let diceMarks = ["ArrowMark", "AxeMark", "HelmetMark", "ShieldMark", "StealMark"]
            diceMarks.forEach(diceMark => {
                this.resources.items[`${diceMark}`].encoding = THREE.sRGBEncoding;
                this.resources.items[`${diceMark}`].repeat = new THREE.Vector2(0.85, 0.85)
                this.resources.items[`${diceMark}`].offset = new THREE.Vector2((1 - 0.85) / 2, (1 - 0.85) / 2)
            })


            this.resources.items.ArrowMark.encoding = THREE.sRGBEncoding;
            this.resources.items.AxeMark.encoding = THREE.sRGBEncoding;
            this.resources.items.HelmetMark.encoding = THREE.sRGBEncoding;
            this.resources.items.ShieldMark.encoding = THREE.sRGBEncoding;
            this.resources.items.TokenMark.encoding = THREE.sRGBEncoding;
            this.resources.items.StealMark.encoding = THREE.sRGBEncoding;


            // console.log("hello");
            this.items = {
                "normal-weapon" : new THREE.MeshStandardMaterial({
                    transparent: true, color: "#feb2b2", 
                }),
                "steal": new THREE.SpriteMaterial({ map: this.resources.items.StealMark, color: 0x737373, transparent : true, depthTest : false, rotation : Math.PI / 2 }),

                "health-stone": new THREE.MeshStandardMaterial({
                    color : 0x00ff11, bumpScale: 0, metalness: 0.164, roughness: 0.164, transparent : true, map: this.resources.items.diceArrowTexture
                }),
                "mjolnir" : new THREE.MeshStandardMaterial({
                    transparent: true, color: "#00ffff", 
                }),
                arrowMark: new THREE.MeshStandardMaterial({
                    map: this.resources.items.ArrowMark,
                    transparent: true,
                    color : "black",
                    opacity: 1
                }),
                axeMark: new THREE.MeshStandardMaterial({
                    map: this.resources.items.AxeMark,
                    transparent: true,
                    color : "black",
                    opacity: 1
                }),
                helmetMark: new THREE.MeshStandardMaterial({
                    map: this.resources.items.HelmetMark,
                    transparent: true,
                    color : "black",
                    opacity: 1
                }),
                shieldMark: new THREE.MeshStandardMaterial({
                    map: this.resources.items.ShieldMark,
                    transparent: true,
                    color : "black",
                    opacity: 1
                }),
                tokenMark: new THREE.MeshStandardMaterial({
                    map: this.resources.items.TokenMark,
                    transparent: true,
                    opacity: 1,
                    color : "#7d6000",
                }),
                stealMark: new THREE.MeshStandardMaterial({
                    map: this.resources.items.StealMark,
                    transparent: true,
                    color : "black",
                    opacity: 1
                }),
                disappearMaterial : ()=>{return new DisappearMaterial()},
                // stamp : new THREE.MeshStandardMaterial({
                //     map : this.resources.items.stamp_map,
                //     normalMap : this.resources.items.stamp_normal,
                //     roughnessMap : this.resources.items.stamp_roughness,
                //     aoMap : this.resources.items.stamp_ao
                // })
                banSign : new THREE.MeshBasicMaterial({
                    map : this.resources.items["ban_sign"],
                    transparent : true,
                    color : 0x800000,
                    // blending : THREE.AdditiveBlending
                })
            }

            // console.log(this.items.arrowMark)
            // console.log(this.items.arrowMark)
            // console.log(this.items["arrowMark"])
            // console.log(this.items["arrowMark"])
            


        })

    }


    getMaterial(name){
        return this.items[`${name}`].clone()
    }



    setDebug(){
        if (this.debug.active) {
            
            this.folder = this.debug.ui.addFolder("Material");

            this.folder.addColor( this.materialColor, 'value' )
            .onChange((event)=>{this.items["normal-weapon"].color.set(event)})


        }

    }


}