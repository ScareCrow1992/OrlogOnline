import * as THREE from 'three'
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'
import EventEmitter from './EventEmitter.js'
import { SVGLoader } from 'three/addons/loaders/SVGLoader.js';


// import { MaterialXLoader } from 'three/examples/jsm/loaders/MaterialXLoader.js';
// import { nodeFrame } from 'three/examples/jsm/renderers/webgl/nodes/WebGLNodes.js';

export default class Resources extends EventEmitter {
    constructor(sources) {
        super()

        this.sources = sources

        this.items = {}
        this.toLoad = this.sources.length
        this.loaded = 0

        this.setLoaders()
        this.startLoading()
    }

    setLoaders() {
        this.loaders = {}
        this.loaders.gltfLoader = new GLTFLoader()
        this.loaders.textureLoader = new THREE.TextureLoader()
        this.loaders.cubeTextureLoader = new THREE.CubeTextureLoader()
        this.loaders.svgLoader = new SVGLoader()
        this.loaders.soundLoader = new THREE.AudioLoader();
        // this.loaders.materialXLoader = new MaterialXLoader()
        // this.loaders.materialXLoader.setPath('https://raw.githubusercontent.com/materialx/MaterialX/main/resources/Materials/Examples/StandardSurface/')

        this.r2_url = "https://orlog-online.com"
        
    }

    startLoading() {
        // Load each source
        for (const source of this.sources) {

            console.log(this.r2_url + source.path)

            if (source.type === 'gltfModel') {
                this.loaders.gltfLoader.load(
                    this.r2_url + source.path,
                    (file) => {
                        this.sourceLoaded(source, file)
                    }
                )
            }
            else if (source.type === 'texture') {
                this.loaders.textureLoader.load(
                    this.r2_url + source.path,
                    (file) => {
                        this.sourceLoaded(source, file)
                    }
                )
            }
            else if (source.type === 'cubeTexture') {
                let paths = new Array(6).fill(this.r2_url)
                paths = paths.map((path, index) => {return path + source.path[index]})
                console.log(paths)
                this.loaders.cubeTextureLoader.load(
                    paths,
                    (file) => {
                        this.sourceLoaded(source, file)
                    }
                )
            }
            else if (source.type === 'svg') {
                this.loaders.svgLoader.load(
                    this.r2_url + source.path,
                    (file) => {
                        this.sourceLoaded(source, file)
                    }
                )
            }
            else if (source.type === 'sound'){
                this.loaders.soundLoader.load(
                    this.r2_url + source.path,
                    (file) => {
                        this.sourceLoaded(source, file)
                    }
                )
                // this.items[`${source.name}`] = new Audio(source.path)
            }
            
        }
    }

    sourceLoaded(source, file) {
        this.items[source.name] = file
        // console.log(file);
        this.loaded++

        if (this.loaded === this.toLoad) {
            this.trigger('ready')
        }
    }
}