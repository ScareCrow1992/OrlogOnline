import WebSocket, { WebSocketServer } from 'ws';
import ServerSocket from "./ServerSocket.js"

import path from 'path';
import http from 'http';
import express from 'express';

import Bluebird from './server/Bluebird.js';


import { fileURLToPath } from 'url';

// import Game from "../client/26-code-structuring-for-bigger-projects-final-main/src/Experience/Game/Game.js"
// import Game from "./src/Game/Game.js"
import Game from "./src/Experience/Game/Game.js"




const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);


const app = express()
const server = http.createServer(app)

const port = 443
const publicDirectoryPath = path.join(__dirname, './');


const wss = new WebSocketServer({server})




app.get('/roomid', (req, res, next)=>{
    let uid = req.query.uid

    // console.log("I receive the req!")
    // console.log(`uid is ~~~~ ${uid}`)
    res.send("0")

})


server.listen(port, () => {
    console.log(`Server is up on port ${port}!`)
})



// const wss = new WebSocketServer({
//     port: 443,
//     perMessageDeflate: {
//         zlibDeflateOptions: {
//             // See zlib defaults.
//             chunkSize: 1024,
//             memLevel: 7,
//             level: 3
//         },
//         zlibInflateOptions: {
//             chunkSize: 10 * 1024
//         },
//         // Other options settable:
//         clientNoContextTakeover: true, // Defaults to negotiated value.
//         serverNoContextTakeover: true, // Defaults to negotiated value.
//         serverMaxWindowBits: 10, // Defaults to negotiated value.
//         // Below options specified as default values.
//         concurrencyLimit: 10, // Limits zlib concurrency for perf.
//         threshold: 1024 // Size (in bytes) below which messages
//         // should not be compressed if context takeover is disabled.
//     }
// });


let player = 0;

let sockets=[]

// console.log(zzz)

wss.on('connection', function connection(ws) {
    console.log(player + " is connected " )
    sockets.push(ws)
    // console.log(sockets.length)

    ws.index = player++

    if(player % 2 == 1)
        return
    
    console.log("match start")

    // console.log(ws)
    // ws.serverSocket = new ServerSocket(ws)
    // ws.game = new Game(ws.serverSocket)
    // serverSocket.InitialGame()

    let topSocket = sockets[player - 2]
    let bottomSocket = sockets[player - 1]

    let data = JSON.stringify(["NeedSwap", []])
    topSocket.send(data)

    let bluebird = new Bluebird()
    bluebird.topsocket = topSocket
    bluebird.bottomsocket = bottomSocket

    
    topSocket.on('message', function message(data) {
        // console.log(data)

        bluebird.Transport(data, topSocket.index)
    });


    bottomSocket.on('message', function message(data) {
        // console.log(data)

        bluebird.Transport(data, bottomSocket.index)
    });


    let game= new Game(bluebird)
    bluebird.game = game

});