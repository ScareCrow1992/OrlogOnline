

// class Button{
//     constructor(config){
//         this.dom
//         this.action
//         this.state
//     }
// }