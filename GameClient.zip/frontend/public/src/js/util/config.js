export default {
    "game-client" : "localhost:8000",
    "game-server" : "localhost:8500",
    "match-maker" : "localhost:9000",
    "static-storage" : "orlog-online.com"
}