// import * as Common from "./common.js"


// // 통합 초기화
// function BulkInitial(name,) {

// }

// // 개별 초기화
// const Initial = {
//     "view-hone": function () {

//     },
//     "view-play": {},
//     "view-about": {},
//     "view-news": {},
//     "view-guide": {},
// }





