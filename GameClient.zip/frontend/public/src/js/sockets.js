let match_waiting_socket;
let game_server_socket



let match_server_host = "ws://localhost:9000/ws?token="
let game_server_host = "ws://localhost:8500/ws?token="


function ConnectToMatchWaiting(matching_token) {
    match_waiting_socket = new WebSocket(`ws://${window.config["match-maker"]}/ws?token=${matching_token}`)
    match_waiting_socket.state = "waiting"

    match_waiting_socket.addEventListener("close", (msg)=>{
        // window.CancleMatchWaiting()
        match_waiting_socket.state = "closed"
    })

    match_waiting_socket.addEventListener("message", (msg) => {
        // console.log(msg.data)
        switch (msg.data) {
            case "1":

                window.OnlineMode(`ws://${window.config["game-server"]}/ws?token=${matching_token}`)
                window.PrepareMatch()

                // game_server_socket = new WebSocket(game_server_host + matching_token)
                // this.redbird = new Redbird()
                // this.redbird.socket = game_server_socket
                // this.redbird.controller = this;

                // game_server_socket.onmessage = (event) => {
                //     this.redbird.Transport(event.data)
                // }
                break;

            case "offer":
                // 매칭서버) 게임 참가 권유
                // match_waiting_socket.send("true")
                // window.NoticeMatchJoinOn()

                Send("true")
                // window.PrepareMatch()
                match_waiting_socket.state = "offered"
                break;
        }
    })
}


function CancleToMatchWaiting(){
    if(match_waiting_socket.state == "waiting"){
        console.log("matching socket is closed")
        // match_waiting_socket.close()
        Send("disconnect")
    }
}


function AcceptMatch() {
    console.log("AcceptMatch")
    if (match_waiting_socket.state == "offered")
        Send("true")
}

function DeclineMatch() {
    if (match_waiting_socket.state == "offered")
        Send("false")

}


function Send(data){
/*
    disconnect : 매칭 대기상태 해제
    true : 매칭 승인
    false : 매칭 거절
*/
    match_waiting_socket.send(data)
}


export { CancleToMatchWaiting, ConnectToMatchWaiting, AcceptMatch, DeclineMatch }
