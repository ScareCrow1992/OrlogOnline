// export default [
//     {
//         name: "view-home",
//         type: "html",
//         path: "home.html"
//     }, {
//         name: "view-play",
//         type: "html",
//         path: "play.html"
//     }, {
//         name: "view-about",
//         type: "html",
//         path: "about.html"
//     }, {
//         name: "view-news",
//         type: "html",
//         path: "news.html"
//     }, {
//         name: "view-guide",
//         type: "html",
//         path: "guide.html"
//     },
// ]