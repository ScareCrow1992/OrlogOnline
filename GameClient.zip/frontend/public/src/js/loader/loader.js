
// import resources from "./resources.js"
// import axios from 'axios'

// let front_server = 'http://localhost:8000'

// let total_cnt = resources.length
// let loaded_cnt = 0
// let items = {}


// function StartLoad() {

//     resources.forEach(resource => {
//         let url = front_server + "/" + resource.type + "/" + resource.path;
//         axios.get(url)
//             .then((resource) => {
//                 items[`${resource.path}`] = resource.data;
//             })



//     })

// }



// function SourceLoaded(loaded_resource) {

// }



