let view
let dict = {}

export default {
    SavePage: (key, dom) => { console.log(dict); dict[`${key}`] = dom },
    LoadPage: (key) => { return dict[`${key}`] },
    InitialView: (view_) => { view = view_ },
    ConvertView: (key) => {
        // console.log(key);
        let dom = dict[`${key}`];
        // console.log(dom)
        while (view.hasChildNodes())
            view.removeChild(view.firstChild);

        view.appendChild(dom)
    }
}





