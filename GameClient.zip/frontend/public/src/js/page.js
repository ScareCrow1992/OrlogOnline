

// class Page {
//     constructor(config) {
//         this.buttons = {}
//         this.children = {}

//     }






// }

