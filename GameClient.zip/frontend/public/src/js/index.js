
// import axios from "axios";

// import PlayPage from "../html/pages/play.html"

import PageAdmin from "/js/page_admin.js"
import ButtonAdmin from "/js/button_admin.js"
import * as DomAdmin from "/js/dom_admin.js"
import * as Auth from "/js/auth.js"
import * as Sockets from "./sockets.js"
import config from "./util/config.js"



let webpage = document.getElementById("webpage-root")
// console.log(webpage)
let gamescreen = document.getElementById("game-canvas")
let view_container = document.getElementById("view")

let blackout = document.getElementById("blackout")
let notice_block = document.getElementById("notice-block")

let notice_description = document.getElementById("notice-description")

let check_mark = document.getElementById("check-wrapper")

gamescreen.style.display = "none"
// webpage.style.display = "none"

window.BlackOn = BlackOn
window.BlackOff = BlackOff
window.GameScreenOn = GameScreenOn
window.GameScreenOff = GameScreenOff
window.NoticeMatchJoinOn = NoticeMatchJoinOn
window.NoticeMatchJoinOff = NoticeMatchJoinOff
window.CancleMatchWaiting = CancleMatchWaiting
window.PrepareMatch = PrepareMatch
window.config = config


BlackOff()


window.addEventListener("keydown", e=>{
    if(e.key == "r"){
        check_mark.style.display = check_mark.style.display == "none" ? "inline-block" : "none"
    }

    if(e.key == "t"){
        webpage.style.display = webpage.style.display == "none" ? "" : "none"
        gamescreen.style.display = gamescreen.style.display == "none" ? "" : "none"
    }

    if(e.key == "o"){
        BlurOn()
        NoticeMatchJoinOn()
        // console.log("blur on")
    }

    if(e.key == "i"){
        BlurOff()
        NoticeMatchJoinOff()
    }

    if (e.key == "z") {
        BlackOn().then(()=>{console.log("Black On")})
        // prom.finished.then(()=>{console.log("black on!")})
    }


    if (e.key == "x") {
        BlackOff().then(()=>{console.log("Black Off")})
        // prom.finished.then(()=>{console.log("black off!")})
    }
})




function BlackOn() {
    let exOpacity = blackout.style.opacity
    NoticeMatchJoinOff()
    DomAdmin.HideMatchAlert()

    let prom = blackout.animate(
        [{opacity : `${exOpacity}`},{opacity : "1.0"}]
        , { duration: 1000 })
    prom.finished.then(() => { blackout.style.opacity = "1.0" })
    return prom.finished
}


function BlackOff() {
    check_mark.style.display = "none"

    let prom = blackout.animate(
        [{opacity : `${blackout.style.opacity}`},{opacity : "0.0"}]
        , { duration: 1000 })
    prom.finished.then(() => { blackout.style.opacity = "0.0" })
    return prom.finished
}


function BlurOn() {
    blackout.style.opacity = "0.7"
}

function BlurOff() {
    blackout.style.opacity = "0.0"
}



function GameScreenOn(){
    console.log("GameScreenOn")
    webpage.style.display = "none"
    gamescreen.style.display = ""

}


function GameScreenOff(){
    console.log("GameScreenOff")
    webpage.style.display = ""
    gamescreen.style.display = "none"
}




function NoticeMatchJoinOn(){
    // obsolete
    BlurOn()
    notice_description.innerText = "The Match Is Ready"
    notice_block.classList.add("visible")
}



function NoticeMatchJoinOff(){
    // obsolete
    BlurOff()
    notice_block.classList.remove("visible")
    check_mark.style.display="none"
}


function PrepareMatch(){
    check_mark.style.display = "inline-block"
}


ButtonAdmin.SaveDom("home", document.getElementById("logo"))

let menuButtons = document.getElementsByClassName("menu-button")
ButtonAdmin.SaveDom("play", menuButtons[0])
ButtonAdmin.SaveDom("guide", menuButtons[1])
ButtonAdmin.SaveDom("news", menuButtons[2])
ButtonAdmin.SaveDom("about", menuButtons[3])

PageAdmin.InitialView(view_container)




let match_cancle_button = document.getElementById("match-cancle-button")
ButtonAdmin.SaveDom("match-cancle-button", match_cancle_button)
ButtonAdmin.RegisterCallback("match-cancle-button", CancleMatchWaiting)





let notice_accept_button = document.getElementById("notice-button-accept")
ButtonAdmin.SaveDom("notice-button-accept", notice_accept_button)
ButtonAdmin.RegisterCallback("notice-button-accept", AcceptMatch)

let notice_decline_button = document.getElementById("notice-button-decline")
ButtonAdmin.SaveDom("notice-button-decline", notice_decline_button)
ButtonAdmin.RegisterCallback("notice-button-decline", DeclineMatch)



function CancleMatchWaiting(){
    Sockets.CancleToMatchWaiting()
    DomAdmin.HideMatchAlert()
}


function AcceptMatch(){
    // obsolete
    notice_description.innerText = "Entering The Game"
    Sockets.AcceptMatch()
}



function DeclineMatch(){
    // obsolete
    Sockets.DeclineMatch()
}



axios.get(`https://${window.config["static-storage"]}/html/pages/home.html`)
    .then((page)=>{
    let dom = CreateElement(page.data, "view-home")
    view_container.appendChild(dom)
    
    PageAdmin.SavePage("home", dom)
    ButtonAdmin.RegisterCallback("home", (pageName)=>{PageAdmin.ConvertView(pageName)})

    // 모듈화 필요
    let tmps = document.getElementsByClassName("content-block-button")
        tmps[0].addEventListener("click", () => { GameStart("constant") })
        tmps[1].addEventListener("click", () => { GameStart("liberty") })
        tmps[2].addEventListener("click", () => { GameStart("draft")})

})



axios.get(`https://${window.config["static-storage"]}/html/pages/play.html`)
    .then((page)=>{
    let dom = CreateElement(page.data, "view-play")
    PageAdmin.SavePage("play", dom)
    ButtonAdmin.RegisterCallback("play", (pageName)=>{PageAdmin.ConvertView(pageName)})
})



axios.get(`https://${window.config["static-storage"]}/html/pages/about.html`)
    .then((page)=>{
    let dom = CreateElement(page.data, "view-about")
    PageAdmin.SavePage("about", dom)
    ButtonAdmin.RegisterCallback("about", (pageName)=>{PageAdmin.ConvertView(pageName)})
})

axios.get(`https://${window.config["static-storage"]}/html/pages/news.html`)
    .then((page)=>{
    let dom = CreateElement(page.data, "view-news")
    PageAdmin.SavePage("news", dom)
    ButtonAdmin.RegisterCallback("news", (pageName)=>{PageAdmin.ConvertView(pageName)})
})


axios.get(`https://${window.config["static-storage"]}/html/pages/guide.html`)
    .then((page)=>{
    let dom = CreateElement(page.data, "view-guide")
    PageAdmin.SavePage("guide", dom)
    ButtonAdmin.RegisterCallback("guide", (pageName)=>{PageAdmin.ConvertView(pageName)})
})


setTimeout(()=>{
    // ButtonAdmin 에게 htmlDOM을 전송한다
}, 3000)



function CreateElement(html, className){
    var nElement = document.createElement('div');
    nElement.classList.add(className)
    nElement.innerHTML = html.trim()
    // let dom = nElement.firstChild;
    // tmpElement.remove()

    return nElement;    
}


function GameStart(game_mode){
    // console.log(Auth)
    DomAdmin.ShowMatchAlert()
    Auth.GameStart(game_mode)
        .then((resolve)=>{
            // resolve.token
            let matchmaking_token = resolve.data
            console.log(matchmaking_token)
            if(matchmaking_token != false){
                Auth.SetMatchAuthToken(matchmaking_token)
                Sockets.ConnectToMatchWaiting(matchmaking_token)
            }
        })
}











let match_alert = document.getElementById("match-alert")
document.addEventListener("keydown", (e)=>{
    if(e.key == 'c'){
        match_alert.classList.add("visible")
    }

    if(e.key == 'v'){
        match_alert.classList.remove("visible")
    }

})






let loading_mark = document.getElementsByClassName("lds-dual-ring")[0]
let currentTime = Date.now()
let deg = 0

tick()
function tick() {
    let delta = Date.now() - currentTime 
    currentTime = Date.now()

    deg += delta * 0.3;
    if(deg > 360)
        deg -= 360
    loading_mark.style.transform =`rotate(${deg}deg)`; 

    window.requestAnimationFrame(() => {
        tick()
    })
}
