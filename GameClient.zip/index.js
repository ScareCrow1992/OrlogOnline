// const path = require('path')
// const http = require('http')
// const express = require('express')
import path from 'path';
import http from 'http';
import express from 'express';
// import cors from "cors";
import axios from 'axios';

import { fileURLToPath } from 'url';
import { OAuth2Client } from 'google-auth-library';

const __filename = fileURLToPath(import.meta.url);

const __dirname = path.dirname(__filename);


const app = express()
const server = http.createServer(app)

const port = 3000
const publicDirectoryPath = path.join(__dirname, './');
// console.log(publicDirectoryPath);


// 다른 routing 함수보다 앞에 설정되어야 함
app.all('/*', (req, res, next) => {
    //res.send(req);
    console.log(req.method + " : " + req.url);
    next();
});


// app.use('/resources/', (req, res, next) =>{
//     // console.log(req.method + " : " + req.url);
//     next(); // 이게 없으면 hanging에 빠진다.
// });

// app.get("/resources/images/dummy/:filename", (req,res,next)=>{
//     console.log(req.method + " : " + req.url);
//     console.log(req.params);
//     next();
// });






// console.log(publicUtilPath);

// express.static 메서드는 node 프로세스가 실행되는 디렉터리에 상대적입니다. 따라서 절대경로를 사용하는 것이 안전할 수 있습니다.
// app.use(express.static(publicDirectoryPath));
// app.use(express.static(publicDirectoryPath, {index : "frontpage.html"}));



// app.use(express.static(publicDirectoryPath, {index : "./src/index.html"}));
app.use(express.static(publicDirectoryPath, { index: "./frontend/public/src/html/index.html" }));
// app.use(express.static('src'));
app.use("/css", express.static('frontend/public/src/css'));
app.use("/js", express.static('frontend/public/src/js'));
app.use("/html", express.static('frontend/public/src/html/pages'))
app.use("/img", express.static('frontend/public/img'));
app.use(express.static('frontend'));
app.use(express.static('node_modules'));
app.use(express.static('auth'));

app.use(express.json())
app.use(express.urlencoded({ extended : true }))

let r2_url = "https://pub-0256486a954c46a6b1aa910ba51cca8f.r2.dev/"

app.use("/textures", express.static('static/textures'));
app.use("/models", express.static('static/models'));
app.use("/sounds", express.static('static/sounds'));
app.use("/gameui", express.static('src'));
app.use("/game", express.static('src'));




app.get('/html', (req, res, next) => {
    res.send("it's ok")
})





const CLIENT_ID = "312285559052-88mj11ch5fb3ipqsn3m7rt0um4a23pva.apps.googleusercontent.com"
const client = new OAuth2Client(CLIENT_ID);


async function verify(req, res, next) {
    let token = null
    req.rawHeaders.forEach(header => {
        let txt = header.split('Bearer ')[1]
        if (txt != null || txt != undefined)
            token = txt
    })

    console.log(token)

    await client.verifyIdToken({
        idToken: token,
        audience: CLIENT_ID,  // Specify the CLIENT_ID of the app that accesses the backend
        // Or, if multiple clients access the backend:
        //[CLIENT_ID_1, CLIENT_ID_2, CLIENT_ID_3]
    }).then((e) => {
        const payload = e.getPayload();
        // return payload
        console.log(payload.sub)
        req.idToken = payload.sub
        next()
    }).catch(() => { res.send("failed to authentication") })
}




let authRouter = express.Router()
authRouter.post('/gamestart', (req, res, next) => {
    // console.log("[[ idToken ]]")
    // console.log(req.idToken)

    // (임시) 게임서버와 통신하여 방번호를 보내준다
    // 백엔드서버는 local host를 통해 게임 서버와 연동한다(보안)

    console.log(``)

    axios.get(`http://match-maker:9000/register_match_pool?uid=${req.idToken}`)
        .then((ret) => {
            if (ret.data != false) {
                // match-making pool에 등록 완료
                // matching token 발급
                res.send(ret.data)
            }
            else
                res.send(false)

        })
        .catch(console.log)
})


app.use('/auth', verify, authRouter)







let totalUsers = 0;


// 요청 코드 : <script type="module" src="/test/script.js"></script>
// Request URL: http://localhost:3000/test/script.js
// Request Method: GET
// Status Code: 404 Not Found

// 요청 코드 : <img src="../resources/images/dummy/orlog_valhalla.jpg">
// Request URL: http://localhost:3000/resources/images/dummy/orlog_valhalla.jpg
// Request Method: GET
// Status Code: 404 Not Found



server.listen(port, () => {
    console.log(`Server is up on port ${port}!`)
})