class Dummy{
    constructor(val){
        this._field = val
    }

    _method(){
        console.log(field_)
    }
}

let a = new Dummy(10)
let b = new Dummy(15)

console.log(Object.is(a._field, b._field))
console.log(Object.is(a._method, b._method))