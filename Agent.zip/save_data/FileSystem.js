
import fs from "fs"

let dir = "./save_data/datas/"
let dice_keys = ["HP-0", "Token-0", "Weapon-0", "Mark-0", "Card-0", "HP-1", "Token-1", "Weapon-1", "Mark-1", "Card-1", "Round", "Winner"]

let godfavor_keys = ["HP-0", "Token-0", "Weapon-0", "Mark-0", "Card-0", "HP-1", "Token-1", "Weapon-1", "Mark-1", "Card-1", "Winner"]

// let wstream_ = fs.createWriteStream('./save_data/datas/data.txt')
// wstream_.write("Hello!")
// wstream_.write("World!")

// let arr = [0,1,2,3,4,5]
// wstream_.write(arr.toString())


let wstreams = {}

dice_keys.forEach(key=>{
    wstreams[`${key}`] = fs.createWriteStream(`./save_data/datas/dices/${key}.txt`)
})

godfavor_keys.forEach(key=>{
    wstreams[`${key}`] = fs.createWriteStream(`./save_data/datas/godfavors/${key}.txt`)
})


function ArraySlice(arr, unit_length){
    let length = arr.length / unit_length
    let ret = []
    for(let index=0; index < length; index++){
        let from = index * unit_length
        let to = from + unit_length

        let sub_array = arr.slice(from, to)
        ret.push(sub_array)
    }

    return ret
}



function Write(log, logs_godfavor){
    dice_keys.forEach(key=>{
        wstreams[`${key}`].write(log[`${key}`].toString() + ",")
    })

    // godfavor_keys.forEach(key=>{
    //     wstreams[`${key}`].write(logs_godfavor[`${key}`].toString() + ",")
    // })
}






function Read() {
    let ret = {}

    dice_keys.forEach(key => {
        let data = fs.readFileSync(`./save_data/datas/dices/${key}.txt`, 'utf-8')

        console.log(`[[ ${key} ]]`)
        // console.log(data)

        let arr = data.split(',')
        arr.pop()

        arr = arr.map(element => {
            return parseInt(element)
        })


        if (key == "Card-0" || key == "Card-1") {
            arr = ArraySlice(arr, 3)
            // console.log(arr)
        }

        if (key == "Weapon-0" || key == "Weapon-1") {
            arr = ArraySlice(arr, 5)
            // console.log(arr)
        }

        console.log(arr.length)

        ret[`${key}`] = arr

    })

    return ret
}


// setTimeout(()=>{
//     let data = Read()
//     console.log(data)

// },3500)


export { Write, Read }



