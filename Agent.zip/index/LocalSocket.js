

export default class LocalSocket {
    constructor(){
        this.othersocket
        this.partnerbird
        this.index

    }

    // json으로 변환되어있음
    send(data){
        this.othersocket.onmessage(data)
    }

    onmessage(data){
        // console.log(data)
        this.partnerbird.Transport(data, this.index)
    }
}