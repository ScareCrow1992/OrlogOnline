// import { createInterface } from "readline"

// import { program, Command } from "commander";
import chalk from "chalk";
import boxen from "boxen";
import inquirer from "inquirer";
import path from "path";
const __dirname = path.resolve();
import Table_Box from "./box/Table_Box.js";
import * as Test from "#test_utils"

import Screen_Controller from "./box/Screen_Controller.js";
import DummyLoader from "#dummy_loader"
import { Random } from "random-js";

const random = new Random();

// import { table } from 'table';


// var blessed = require('blessed');
// var chalk = require('chalk');

function Create_Test_Data(){

}


const game_modes = ["constant", "liberty", "draft"]

class CLI {
    constructor() {

        this.screen = new Screen_Controller(this)
        this.dummy_loader = new DummyLoader()

        this.interval_auto_work = null

        // this.agent_tables_box = new Table_Box(this.screen)
        // console.log(box.display_agent_limit_cnt)

        global.print_console = (txt) => { this.Print(txt) }
    }

    get dummies_cnt(){
        return this.dummy_loader.dummies_cnt
    }


    Print(txt){
        this.screen.Print(txt)
    }



    Test_show_agents_table(){
        let agent_cnt = this.screen.display_agent_cnt

        let test_agent_data = Test.AgentTableDatas(agent_cnt)
        // console.log(test_agent_data)
        this.screen.ShowAgents(test_agent_data)


        // this.Render()
    }



    // 특정 index를 시작점으로 하여 테이블들을 살펴본다
    ViewIndex(agent_index){

    }


    //
    ViewFilter(){

    }

    // 
    ViewSort(){

    }


    auto_(total, interval_cnt, option){
        this.Print(`[auto] total : ${total}, interval : ${interval_cnt}`)
        // this.Print(`[auto] from : ${option["f"]}, cnt : ${option["c"]}`)

        // let index = option["f"]
        // let cnt = option["c"]

        if(this.interval_auto_work == null){
            this.interval_auto_work = setInterval(()=>{
                let loader_info = this.dummy_loader.loader_info

                let nonIdle_cnt = loader_info["total"] - loader_info["idle"]

                let extra_cnt = total - nonIdle_cnt
                let cnt = Math.min(extra_cnt, interval_cnt)
                cnt = Math.max(0, cnt)

                let game_mode = game_modes[random.integer(0, 2)]

                this.Print(`[auto] cnt : ${cnt}, mode : ${game_mode}`)
                this.run_(0, cnt, {m : game_mode})


            }, 5000)
        }
    }


    release_(){
        if(this.interval_auto_work != null){
            clearInterval(this.interval_auto_work)
            this.interval_auto_work = null
        }

    }




    clear_() {
        this.screen.clear()
    }


    // 에이전트 생성
    create_(cnt) {
        this.dummy_loader.CreateDummy(cnt)
    }

    show_(from) {
        if (typeof from !== "number")
            return;

        let cnt = this.screen.display_agent_cnt

        let infos = this.dummy_loader.GetDummyInfo(from, cnt)
        this.screen.ShowAgents(infos)
        this.info()
    }

    work_(from, cnt){

    }


    info(){
        let info = this.dummy_loader.loader_info
        this.screen.ShowStatus(info)
    }


    run_(index, cnt, option){
        [index, cnt] = this.screen.RunAgents(index, cnt)

        let game_mode = option["m"]

        // console.log(option)
        // let keys = Object.keys(option)

        // this.Print(`[[ run (${index}, ${cnt}) ]]`)

        let registered_cnt = this.dummy_loader.WorkLoad(index, cnt, game_mode)
        this.Print(`[run] (${index}, ${registered_cnt}) , ${game_mode}`)

    }

}

let cli = new CLI()
// cli.Test_show_agents_table()



// console.log(table(Test.AgentTableDatas(4,25)[0]))




// Create a screen object.

// Create a box perfectly centered horizontally and vertically.


// Append our box to the screen.
// screen.append(box);

// Add a png icon to the box
// var icon = blessed.image({
//     parent: box,
//     top: 0,
//     left: 0,
//     type: 'overlay',
//     width: 'shrink',
//     height: 'shrink',
//     file: __dirname + '/my-program-icon.png',
//     search: false
// });

// // If our box is clicked, change the content.
// box.on('click', function (data) {
//     box.setContent('{center}Some different {red-fg}content{/red-fg}.{/center}');
//     screen.render();
// });

// If box is focused, handle `enter`/`return` and give us some more content.

// Quit on Escape, q, or Control-C.

// Focus our element.

// Render the screen.


// class CLI{
//     constructor(){
//         this.readline = createInterface({
//             input: process.stdin,
//             output: process.stdout,
//         })
//     }


//     Question(){
//         this.readline.question(`What's your name?`, name => {
//             console.log(`Hi ${name}!`);
//             this.readline.close();
//         });
//     }

// }


