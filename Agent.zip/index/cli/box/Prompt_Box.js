export default class Prompt_Box{
    constructor(){
        
    }
}