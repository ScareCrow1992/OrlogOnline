
export default function (agent_index, situation, firstuser, game_mode) {
    this.godFavors = situation.player[agent_index].godFavors


}