// { user: player, godfavors: [player * 3, player * 3 + 1, player * 3 + 2] }


import { Random } from "random-js";

const random = new Random();

let arr = new Array(20)
for (let i = 0; i < arr.length; i++)
    arr[i] = i


export default function (index) {
    random.shuffle(arr)



    return ["BellPushed", [index, { user: index, godfavors: [arr[0], arr[1], arr[2]] }, "cardselect",
        [{ "dicesState": ["chosen", "chosen", "chosen", "chosen", "chosen", "chosen"], health: 15, token: 10 },
        { "dicesState": ["chosen", "chosen", "chosen", "chosen", "chosen", "chosen"], health: 15, token: 10 }]]]

}

