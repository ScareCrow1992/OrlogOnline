// import Situation from "../Data/this.js"
// import mongo from "../../server/db/mongo.js"

const dirI2S = ["right", "left", "top", "bottom", "front", "back"]
const dicePickLimitTurn = 4


function PushLog() {
    let parsed_situation = ParsingSituation.call(this)
    this.logs.push(parsed_situation)
}


function ParsingSituation() {
    let parsed_log =
        [{ axe: 0, arrow: 0, helmet: 0, shield: 0, steal: 0, mark: 0 },
        { axe: 0, arrow: 0, helmet: 0, shield: 0, steal: 0, mark: 0 },
        { first: 0, turn: 0 }]

    // console.log(dices)
    parsed_log[2].first = this.order[0]
    parsed_log[2].turn = this.turnNum

    for (let user = 0; user < 2; user++) {
        parsed_log[user].hp = this.player[user].health
        parsed_log[user].token = this.player[user].token

        let dices = this.player[user].dices
        for (let i = 0; i < 6; i++) {
            if (dices[i].state == "waiting") {
                let weapon = dices[i].weapon
                parsed_log[user][`${weapon}`]++
            }
            parsed_log[user].mark += dices[i].token ? 1 : 0
        }
    }
    // console.log(parsed_log)

    return parsed_log
}





function _PrintSituation() {
    console.log("=============================")
    console.log(`round : ${this.round}`)
    console.log(`[[ player 0 ]]`)
    console.log(`HP : ${this.player[0].health} / token : ${this.player[0].token}`)
    console.log(`[[ player 1 ]]`)
    console.log(`HP : ${this.player[1].health} / token : ${this.player[1].token}`)

}



function ChangePhase(new_phase) {
    if (this.phase != "end") {
        this.phase = new_phase
    }
}


function GetFirstPlayer() {
    let firstPlayer = Math.floor(Math.random() * 10) % 2
    // this.order[1 - firstPlayer] = "top"
    // this.order[firstPlayer] = "bottom"
    this.order[0] = firstPlayer
    this.order[1] = 1 - firstPlayer

    // this.phase = "cardselect"
    ChangePhase.call(this, "cardselect")


    return firstPlayer
}


function InitialGame() {
    // eventEmitters.on("initial-game", ()=>{console.log("trigger")})
    // eventEmitters.trigger("initial-game")
    // eventEmitters.trigger("game")

    // console.log(this)

    // console.log("[[[ Initial Game ]]]")
    // console.log(this)

    this.eventEmitter.reset()


    // console.log(this)

    this.round = 0
    // this.phase = "roll"
    ChangePhase.call(this, "roll")

    this.turnNum = 0
    this.winner = "none"

    this.turnEnd[0] = false
    this.turnEnd[1] = false


    let players = [0, 1]
    players.forEach(player_ => {
        let player = this.player[player_]
        player.health = 15
        player.token = 0
        player.dices.forEach(dice => { dice.state = "tray" })
    })

    // console.log("Initialize the Game")

    // controller.InitialGame();
}

function TakeHeal(user, value) {
    this.player[user].health += value
    this.player[user].health = Math.min(15, this.player[user].health)
}



function TakeDamage(user, damage, weapon) {
    this.eventEmitter.trigger(`${user}-damage-${weapon}`, [damage])
    this.player[user].health -= damage

    if (damage > 0) {
        // console.log(`[ ${user} ] - damaged by ${weapon} ( ${this.player[user].health + damage} => ${this.player[user].health} )`)
        // mongo.InsertLog(this.doc_id, `[ ${user} ] - damaged by ${weapon} ( ${this.player[user].health + damage} => ${this.player[user].health} )`)

        // this.logs.push(`[ ${user} ] - damaged by ${weapon} ( ${this.player[user].health + damage} => ${this.player[user].health} )`)
    }

    if (this.player[user].health <= 0 && this.winner == "none") {
        this.winner = 1 - user;
        // this.phase = "end";
        ChangePhase.call(this, "end")
        // console.log("[[[ !!!  phase is turn to end  !!! ]]]")
    }
}


function BlockAttack(user, cnt, weapon) {
    this.eventEmitter.trigger(`${user}-block-${weapon}`, [cnt])
    if (cnt > 0) {
        // console.log(`[ ${user} ] - blocking the ${weapon} **${cnt}**`)
        // mongo.InsertLog(this.doc_id, `[ ${user} ] - blocking the ${weapon} **${cnt}**`)
        // this.logs.push(`[ ${user} ] - blocking the ${weapon} **${cnt}**`)

    }
}

function StealToken(defender, cnt) {
    let attacker = 1 - defender

    let canStealTokensCnt = Math.min(
        this.player[`${defender}`].token,
        cnt)

    this.player[`${defender}`].token -= canStealTokensCnt
    this.player[`${attacker}`].token += canStealTokensCnt


}


function AddToken(user, cnt) {
    this.player[`${user}`].token += cnt
    this.player[`${user}`].token = Math.min(
        this.player[`${user}`].token, 50
    )

}

function RemoveToken(user, cnt) {
    this.player[`${user}`].token -= cnt
    this.player[`${user}`].token = Math.max(
        this.player[`${user}`].token, 0)
}


// sector 단위로 상세하게 과정 나눠야함 (Hel 능력이 도끼에만 한정되므로)
// function BattleSimulation(battleResult) {
//     let firstAvatar = this.order[0]
//     let secondAvatar = this.order[1]

//     let canStealTokensCnt = Math.min(
//         this.player[`${secondAvatar}`].token,
//         battleResult[1].stealedToken)

//     this.player[`${secondAvatar}`].health -= battleResult[1].takenDamage
//     this.player[`${secondAvatar}`].token -= canStealTokensCnt
//     this.player[`${firstAvatar}`].token += canStealTokensCnt
//     // Hel 트리거 = 공격자 체력 증가(도끼데미지)

//     if (this.player[`${secondAvatar}`].health <= 0)
//         return firstAvatar

//     canStealTokensCnt = Math.min(
//         this.player[`${firstAvatar}`].token,
//         battleResult[0].stealedToken)

//     this.player[`${firstAvatar}`].health -= battleResult[0].takenDamage
//     this.player[`${firstAvatar}`].token -= canStealTokensCnt
//     this.player[`${secondAvatar}`].token += canStealTokensCnt
//     // Hel 트리거 = 공격자 체력 증가 (도끼데미지)

//     if (this.player[`${firstAvatar}`].health <= 0)
//         return secondAvatar


//     return null
// }



// // param = [[선공], [후공]]
// // dicesCommand = [[ 공방 횟수, 명치 횟수 ],[]]
// // battleResult = [{ takenDamage : <int> , stealedToken : <int> }, {}]
// function DiceBattle(dicesCommand, battleResult, controller) {
//     let whoIsWin = BattleSimulation(battleResult)

//     return controller.MessageEnqueue("DiceBattle", [dicesCommand, this.order])

// }





function GetDicesInfo() {
    let first = this.order[0]
    let second = this.order[1]
    // console.log(...this.player[`${first}`].dices)
    // console.log(...this.player[`${second}`].dices)
    return [[...this.player[`${first}`].dices], [...this.player[`${second}`].dices]]

}


function StartRound() {
    // 체력, 토큰, 주사위, situation 등 모든 정보를 리셋
    // mongo.InsertLog(this.doc_id, `round : ${this.round}`)
    // this.logs.push(`round : ${this.round}`)

    let avatar = this.order[0 % 2]
    this.turnEnd[0] = false
    this.turnEnd[1] = false
    this.preparedGodFavor[0].godfavorIndex = -1
    this.preparedGodFavor[0].level = -1
    this.preparedGodFavor[0].godfavorNameIndex = -1
    this.preparedGodFavor[1].godfavorIndex = -1
    this.preparedGodFavor[1].level = -1
    this.preparedGodFavor[1].godfavorNameIndex = -1

    this.round++

    return avatar
}



function ResetRound() {
    // console.log(`round : ${this.round}`)

    // _PrintSituation.call(this)
    // ParsingSituation.call(this)

    // this.phase = "roll"
    ChangePhase.call(this, "roll")
    this.turnNum = 0
    this.orderSwap()

    for (let i = 0; i < 6; i++) {
        this.player[0].dices[i].state = "tray"
        this.player[0].dices[i].power = 1

        this.player[1].dices[i].state = "tray"
        this.player[1].dices[i].power = 1
    }

    this.player.forEach(user => {
        while (user.dices.length > 6)
            user.dices.pop()
    })

    this.resolutionWaitInputForUser = -1
    this.eventEmitter.reset()

    // console.log(Situation)

    return WhoIsWinner.call(this)
}


function WhoIsWinner() {
    // console.log(this.winner)
    if (this.winner != "none") {
        // this.logs.push(`winner : ${this.winner}`)
        // mongo.InsertLog(this.doc_id, this.logs)


    }
    return this.winner
}



function RegisterEvent(trigger, callback) {
    this.eventEmitter.on(`${trigger}`, (param) => { callback(param) })
}

function TriggerEvent(trigger, value) {
    // console.log(trigger)
    // console.log(value)
    this.eventEmitter.trigger(`${trigger}`, value)
}


function SetFormation() {

}


/*

[playerInfo]

"godfavor"
godFavorIndex, level
*/





function BellPushed(avatar, playerInfo = null, avatarsInfo = null) {
    // isLastTurn = isLastTurn || false
    switch (this.phase) {
        case "roll":
            let prevAvatar
            // if (isLastTurn) {
            //     prevAvatar = this.order[(this.turnNum + 1) % 2]
            //     avatar = prevAvatar
            // }
            // else

            prevAvatar = this.order[this.turnNum % 2]

            // console.log(`${avatar}, ${prevAvatar}`)
            if (avatar == prevAvatar) {
                let prevDices = this.player[`${prevAvatar}`].dices
                let dicesStateFromClient
                if (avatarsInfo != null)
                    dicesStateFromClient = avatarsInfo[prevAvatar].dicesState
                else {
                    prevDices.forEach((dice, index) => {
                        if (dice.state === "waiting")
                            dicesStateFromClient = "waiting"
                        else
                            dicesStateFromClient = "chosen"
                    })
                }



                // 이전 플레이어의 chosen 주사위들을 waiting 상태로 바꾼다.
                let chosenDices = []
                prevDices.forEach((dice, index) => {

                    if ((this.turnNum < dicePickLimitTurn && dice.state === "tray" && dicesStateFromClient[index] === "chosen") ||
                        (this.turnNum >= dicePickLimitTurn && dice.state === "tray")
                    ) {
                        // 1. 주사위 턴이 남아있을경우 선택된 주사위를 waiting으로
                        // 2. 주사위 턴이 더이상 없을 경우 남은 굴린 후 곧바로 waiting으로
                        dice.state = "waiting"
                        chosenDices.push(index)
                    }


                })

                // controller.MessageEnqueue("DicesToWaiting", [avatar, chosenDices])
                PushLog.call(this)

                // 턴 증가
                this.turnNum++;

                let nextAction
                if (this.turnNum < 6)
                    nextAction = "RollDice";
                else {
                    // this.phase = "godfavor"
                    ChangePhase.call(this, "godfavor")
                    nextAction = "RollPhaseEnd";
                }


                return { isCallback: true, func: "DicesToWaiting", params: [avatar, chosenDices], nextAction: nextAction }

            }
            else
                return { isCallback: null, nextAction: null }

            break;

        case "godfavor":
            // PrepareGodFavor(godFavorIndex, level, user)
            if (playerInfo != null)
                PrepareGodFavor.call(this, playerInfo.godFavorIndex, playerInfo.level, avatar)
            this.turnEnd[`${avatar}`] = true
            if (this.turnEnd[0] == true && this.turnEnd[1] == true) {
                // this.phase = "resolution"
                ChangePhase.call(this, "resolution")
                return { isCallback: false, nextAction: "GodFavorEnd" };
            }
            else
                return { isCallback: false };


            break;
    }

    return { isCallback: null, nextAction: null }
}


// 굴려야 할 주사위 갯수 반환
function GetRollDicesCnt(avatar) {
    // console.log(this)
    let cnt = 0;
    this.player[`${avatar}`].dices.forEach(dice => {
        cnt += (dice.state === "tray" ? 1 : 0)
    })
    return cnt;
}

// function PushDicesLog(){
//     let str = "~~[ "
//     let dices = this.player[0].dices
//     dices.forEach(dice=>{
//         str += " " + dice.weapon + " "
//     })

//     str += " ] / [ "

//     dices = this.player[1].dices
//     dices.forEach(dice=>{
//         str += " " + dice.weapon + " "
//     })

//     str += " ] ~~"

//     mongo.InsertLog(this.doc_id, str)
//     // console.log(str)
// }


// avatar : "top" or "bottom"
// dirs : [0,2,1,2,4,2]      (주사위 방향 정보)
function RollDices(avatar, dirs) {
    // console.log ("\n\nRollDices\n\n")
    this.player[`${avatar}`].dices.forEach((dice, index) => {
        if (dice.state == "tray") {
            dice.dir = dirI2S[dirs[index]]
            dirs[index] = dice.dir
        }
        else
            dirs[index] = null;
    })
    // console.log(this.turnNum)

    let rollDicesCnt = GetRollDicesCnt.call(this, avatar)

    let ret
    if (this.turnNum >= dicePickLimitTurn || rollDicesCnt == 0)
        ret = true
    else
        ret = false;

    let avatar_stats = ParsingSituation.call(this)

    // PushDicesLog.call(this)

    // controller.MessageEnqueue("RollDices", [avatar, dirs, rollDicesCnt, ret])
    return { func: "RollDices", params: [avatar, dirs, rollDicesCnt, avatar_stats], isDicePickLimit: ret }

}


/* objInfo = { type : "dice", index : 0, avatar : "top" } */
function SelectObject(objInfo,) {

    // this.phase = "hello"
    // console.log(this.phase)
    // console.log(objInfo)
    switch (this.phase) {
        case "roll":
            if (objInfo.type == "dice")
                return pickUpDice.call(this, objInfo)


            break;

        case "godfavor":
            if (objInfo.type == "godfavor")
                return choiseGodFavor.call(this, objInfo)

            break;

        case "resolution":
            if (objInfo.type == "dice") {
            }
            break;

    }

    return null
}




function pickUpDice(objInfo) {
    let currentTurnAvatar = this.order[this.turnNum % 2]
    // "bottom" or "top"

    // 평범한 주사위 선택
    if (currentTurnAvatar == objInfo.avatar && this.turnNum < dicePickLimitTurn) {

        let diceState = this.player[`${currentTurnAvatar}`].dices[objInfo.index].state
        // console.log(diceState)
        switch (diceState) {
            case "tray":
                return ChooseDice.call(this, currentTurnAvatar, objInfo.index)
                break;

            case "chosen":
                return CancleDice.call(this, currentTurnAvatar, objInfo.index)
                break;

            case "waiting":

                break;
        }
    }
    return null
}


function ChooseDice(avatar, index) {
    this.player[`${avatar}`].dices[index].state = "chosen";
    // controller.ChooseDice(avatar, index);

    return { callback: "ChooseDice", avatar: avatar, index: index }

}


function CancleDice(avatar, index) {
    this.player[`${avatar}`].dices[index].state = "tray"
    // controller.CancleDice(avatar, index)
    return { callback: "CancleDice", avatar: avatar, index: index }

}


function GetToken(dicesWithTokenIndex) {
    this.order.forEach((avatar, index) => {
        this.player[`${avatar}`].token += dicesWithTokenIndex[index].length
    })

    // controller.GetToken(this.order, dicesWithTokenIndex)
    // let promise = controller.MessageEnqueue("GetToken", [this.order, dicesWithTokenIndex])

    // return promise
}


function choiseGodFavor() {



}


function ExceptDicesFromBattle(cnt) {

}


function GetPlayerOrder() {
    return this.order
}


function PushResolutionPhaseCommands(cmds) {
    this.resolutionCallIndex = 0
    // console.log(cmds)
    this.resolutionCallbacks = cmds
    // this.resolutionCallbacks = JSON.parse(JSON.stringify(cmds))
    // console.log(this.resolutionCallbacks)
}


function GetNextResolutionPhaseCommand() {
    // console.log("[supervisor] : callbacks = " + this.resolutionCallbacks)
    // console.log("[supervisor] : index = " + this.resolutionCallIndex)
    // console.log("[supervisor] : wait user = " + this.resolutionWaitInputForUser)
    if (this.resolutionWaitInputForUser != -1)
        return null

    this.resolutionWaitInputForUser = -1

    if (this.resolutionCallIndex >= this.resolutionCallbacks.length)
        return null
    else {
        // console.log("length : " + this.resolutionCallbacks.length)
        // console.log("index : " + this.resolutionCallIndex)
        // console.log(this.resolutionCallbacks)
        let ret = this.resolutionCallbacks[this.resolutionCallIndex++]
        // console.log(ret)
        return ret;
    }
}


function WaitForPlayerInputAtResolutionPhase(user) {
    this.resolutionWaitInputForUser = user
    // console.log("[supvervisor] : setting the wait user = " + this.resolutionWaitInputForUser + ", " + user)
}


function GetResolutionPhaseInputWaitUser(avatarsInfo, inputInfo, avatar) {
    let waituser = this.resolutionWaitInputForUser
    if (waituser == avatar) {
        this.resolutionWaitInputForUser = -1
        this.extraInput = JSON.parse(JSON.stringify(avatarsInfo))
        this.inputInfo = JSON.parse(JSON.stringify(inputInfo))
        // console.log(this.extraInput)
    }
    // console.log("get wait user : " + waituser)
    return waituser
}


function GetExtraInputData() {
    return this.extraInput
}


function GetInputData() {
    return this.inputInfo
}


function PrepareGodFavor(godFavorIndex, level, user) {
    // console.log(this.godFavorNames)
    if (this.turnEnd[user] == false) {
        this.preparedGodFavor[user].godfavorIndex = godFavorIndex
        this.preparedGodFavor[user].level = level
        this.preparedGodFavor[user].godfavorNameIndex = this.player[user].godFavors[godFavorIndex]
        // console.log(this.preparedGodFavor[user])
    }

}


// function ActivateGodFavorPower(godfavorInfo) {
//     let callback = null

//     // let cost = godfavorInfo.cost[godfavorInfo.level]
//     let user = godfavorInfo.user

//     if (this.player[`${user}`].token >= godfavorInfo.cost_) {
//         // 토큰 소비
//         this.player[`${user}`].token -= godfavorInfo.cost_
//         if (godfavorInfo.level >= 0) {
//             // 능력 사용
//             callback = godfavorInfo.power(Situation)
//             // console.log(ret)
//         }
//     }

//     return callback
// }


function GetPreparedGodFavor() {
    let preparedGodFavor = this.preparedGodFavor
    preparedGodFavor = JSON.parse(JSON.stringify(preparedGodFavor))
    return preparedGodFavor
}



function GetCurrentPhase() {
    // console.log(`[ phase ] : ${this.phase}`)
    return this.phase
}


// this.player[user].dices[indexes[i]] = state
function SetDicesState(user, indexes, state) {
    indexes.forEach(index => {
        this.player[user].dices[index].state = state
    })

}

function SetDicesDir(user, indexes, dirs) {
    let cnt = dirs.length
    let dices = this.player[user].dices
    // console.log(this.player[user].dices)
    for (let i = 0; i < dirs.length; i++) {
        let dir = dirs[i]
        let index = indexes[i]
        dices[index].dir = dir
    }
    // console.log(this.player[user].dices)
}


function GodFavorCardsPick(user, picked_godfavors) {
    if (this.turnEnd[user])
        return false

    this.turnEnd[user] = true
    this.player[user].godFavors[0] = picked_godfavors[0]
    this.player[user].godFavors[1] = picked_godfavors[1]
    this.player[user].godFavors[2] = picked_godfavors[2]

    if (this.turnEnd[0] && this.turnEnd[1])
        return true // 카드 선택 작업 완료, 본격적인 게임 시작
    else
        return false;

}


// 배포 금지
function _WARNING_CHANGE_PHASE(phase) {
    this.phase = phase;
}


function DEV_ChooseDice(avatar, index, controller) {
    if (this.phase == "resolution")
        return;
    ChooseDice(avatar, index, controller);
}


function DEV_CancleDice(avatar, index, controller) {
    if (this.phase == "resolution")
        return;

    CancleDice(avatar, index, controller)
}

function DEV_StandbyDice(avatar, index, controller) {
    if (this.phase == "resolution")
        return;

}

function DEV_GodPower_Cost() {
    if (this.phase == "resolution")
        return;
}


function DEV_GodPower_Nocost() {
    if (this.phase == "resolution")
        return;
}



export {
    GetFirstPlayer, InitialGame, RollDices, SelectObject, TakeDamage, BlockAttack, BellPushed, GetRollDicesCnt, ResetRound, StartRound, GetDicesInfo, GetToken, GetPlayerOrder, PrepareGodFavor, GetPreparedGodFavor, GetCurrentPhase, PushResolutionPhaseCommands, GetNextResolutionPhaseCommand, WaitForPlayerInputAtResolutionPhase, GetResolutionPhaseInputWaitUser, GetExtraInputData, SetDicesState, SetDicesDir, RegisterEvent, TriggerEvent, TakeHeal, StealToken, AddToken, RemoveToken, GetInputData, GodFavorCardsPick

    , DEV_ChooseDice, DEV_CancleDice, DEV_StandbyDice
}