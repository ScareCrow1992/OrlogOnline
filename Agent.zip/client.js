// import axios from "axios";

// for(let i=0; i<100 ;i++){
//     axios.get(`http://127.0.0.1:35557/user/profile?id=${i}`)
//     .then((ret) => {
//         console.log(ret.data)
//     })
//     .catch(console.log)
// }
// axios.get(`http://127.0.0.1:7373/app1`)
//     .then((ret) => { console.log(ret.data)})

import WebSocket from 'ws';
//34.123.29.3



let ws = new WebSocket("wss://gs.orlog.io/hello")
// let ws = new WebSocket("ws://34.123.29.3:80/hello")
// let ws = new WebSocket("ws://34.67.242.12:80/hello")
// emitter.setMaxListeners(25)
for(let i=0; i<10; i++){
    ws.on("open", (data) => {
        // let index = i % 4
        console.log("connected~")
        // let index = 31
        ws.send(`[socket - ${i}] hello`)
        // setInterval(()=>{ ws.send(`[socket - ${i}] hello`) },10000)
        // ws.send("hello~")
    })
}



// for(let i=0; i<100 ;i++){
//     let ws = new WebSocket(`ws://127.0.0.1:${7370 + (i % 4)}/hello`)
//     ws.on("open", (data) => {
//         let index = i % 4
//         console.log(index.toString())
//         ws.send(index.toString())
//     })
// }
